from utils.validators import require_fields, valid_date
from views.base_page import BasePage, TableMixin, FormDialog


CONTAINER_TYPES = ["20GP", "40GP", "40HC"]
CONTAINER_STATUSES = ["Rỗng", "Đang đóng hàng", "Đã đóng hàng", "Tại cảng", "Đã rời cảng", "Đang vận chuyển", "Đã đến", "Đã dỡ hàng"]


class ContainerPage(BasePage, TableMixin):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Quản lý container")
        self.build_filter_bar(self, [("Mã container", "code", None), ("Cảng", "port", None), ("Trạng thái", "status", [""] + CONTAINER_STATUSES)])
        self.build_action_bar(self, [("Thêm container", self.add_container), ("Chỉnh sửa", self.edit_container), ("Cập nhật trạng thái", self.set_status)])
        columns = ("code", "type", "shipment", "location", "from", "to", "depart", "eta", "status")
        headings = ("Mã container", "Loại", "Lô hàng", "Vị trí hiện tại", "Cảng đi", "Cảng đến", "Khởi hành", "ETA", "Trạng thái")
        self.build_table(self, columns, headings, {"location": 160})

    def refresh(self):
        self.app.alert_service.check_container_eta()
        self.db.commit()
        filters = {k: v.get() for k, v in self.filter_vars.items() if v.get()}
        self.clear_table()
        for row in self.app.transport_service.list_containers(filters):
            self.tree.insert("", "end", iid=row["id"], values=(
                row["code"], row["type"], row["shipment_code"] or "", row["current_location"],
                row["port_from"] or "", row["port_to"] or "", row["departure_date"] or "", row["eta"] or "", row["status"]
            ))

    def _fields(self):
        return [
            ("Loại container", "type", CONTAINER_TYPES),
            ("Vị trí hiện tại", "current_location"),
            ("Cảng đi", "port_from"),
            ("Cảng đến", "port_to"),
            ("Ngày khởi hành (YYYY-MM-DD)", "departure_date"),
            ("ETA (YYYY-MM-DD)", "eta"),
            ("Trạng thái", "status", CONTAINER_STATUSES),
        ]

    def add_container(self):
        dialog = FormDialog(self, "Thêm container", [("Mã container", "code")] + self._fields(), {
            "code": self.app.transport_service.next_container_code(),
            "type": "20GP",
            "status": "Rỗng",
        })
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["mã container", "loại", "vị trí", "cảng đi", "cảng đến", "khởi hành", "ETA", "trạng thái"])
            self.app.transport_service.add_container(
                data["code"], data["type"], data["current_location"], data["port_from"], data["port_to"],
                valid_date(data["departure_date"], "Ngày khởi hành"), valid_date(data["eta"], "ETA"), data["status"]
            )
            self.notify_success("Container đã được thêm.")
        except Exception as exc:
            self.notify_error(exc)

    def edit_container(self):
        if not self.selected_required():
            return
        row = self.db.fetch_one("SELECT * FROM containers WHERE id=%s", (self.selected_id,))
        dialog = FormDialog(self, "Chỉnh sửa container", self._fields(), row)
        if not dialog.result:
            return
        try:
            data = dialog.result
            self.app.transport_service.update_container(
                self.selected_id, data["type"], data["current_location"], data["port_from"], data["port_to"],
                valid_date(data["departure_date"], "Ngày khởi hành"), valid_date(data["eta"], "ETA"), data["status"]
            )
            self.notify_success("Container đã được cập nhật.")
        except Exception as exc:
            self.notify_error(exc)

    def set_status(self):
        if not self.selected_required():
            return
        dialog = FormDialog(self, "Cập nhật trạng thái container", [("Trạng thái", "status", CONTAINER_STATUSES)])
        if not dialog.result:
            return
        try:
            self.app.transport_service.set_container_status(self.selected_id, dialog.result["status"])
            self.notify_success("Trạng thái container đã được cập nhật.")
        except Exception as exc:
            self.notify_error(exc)

