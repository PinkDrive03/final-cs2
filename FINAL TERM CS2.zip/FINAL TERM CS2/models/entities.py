from dataclasses import dataclass
from datetime import date


@dataclass
class Customer:
    code: str
    name: str
    phone: str
    address: str


@dataclass
class Product:
    sku: str
    name: str
    unit: str
    min_stock: int


@dataclass
class Warehouse:
    code: str
    name: str
    address: str


@dataclass
class Order:
    code: str
    customer_id: int
    order_date: date
    delivery_address: str
    priority: str
    status: str


@dataclass
class Shipment:
    code: str
    order_id: int
    origin: str
    destination: str
    expected_arrival: date
    status: str


@dataclass
class Container:
    code: str
    type: str
    current_location: str
    status: str


@dataclass
class Vehicle:
    code: str
    plate: str
    vehicle_type: str
    capacity: float
    driver: str
    status: str


@dataclass
class Alert:
    code: str
    type: str
    related_table: str
    related_id: int
    issue_key: str
    content: str
    severity: str
    status: str
