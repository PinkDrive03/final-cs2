from tkinter import messagebox

from utils.validators import require_fields
from views.base_page import BasePage, TableMixin, FormDialog, choice_label, id_from_choice


class WarehousePage(BasePage, TableMixin):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Kho & vị trí hàng")
        top = self._build_search()
        self.build_action_bar(self, [("Thêm kho", self.add_warehouse), ("Thêm vị trí", self.add_location)])
        columns = ("sku", "name", "warehouse", "area", "rack", "bin", "quantity")
        headings = ("SKU", "Sản phẩm", "Kho", "Khu vực", "Kệ", "Ngăn", "Số lượng")
        self.build_table(self, columns, headings, {"name": 180, "warehouse": 160})

    def _build_search(self):
        import tkinter as tk
        from tkinter import ttk

        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(0, 8))
        ttk.Label(bar, text="Nhập SKU hoặc tên sản phẩm").pack(side="left", padx=(0, 8))
        self.keyword_var = tk.StringVar()
        ttk.Entry(bar, textvariable=self.keyword_var, width=32).pack(side="left", padx=(0, 8))
        ttk.Button(bar, text="Tìm kiếm", command=self.refresh).pack(side="left", padx=4)
        ttk.Button(bar, text="Xóa bộ lọc", command=self.clear_search).pack(side="left", padx=4)
        return bar

    def refresh(self):
        self.clear_table()
        rows = self.app.inventory_service.search_location(self.keyword_var.get().strip())
        for row in rows:
            self.insert_row(row["id"], (
                row["sku"], row["product_name"], f"{row['warehouse_code']} - {row['warehouse_name']}",
                row["area"], row["rack"], row["bin"], row["quantity"]
            ))

    def clear_search(self):
        self.keyword_var.set("")
        self.refresh()

    def add_warehouse(self):
        dialog = FormDialog(self, "Thêm kho", [
            ("Mã kho", "code"),
            ("Tên kho", "name"),
            ("Địa chỉ", "address"),
        ])
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["mã kho", "tên kho", "địa chỉ"])
            self.app.inventory_service.add_warehouse(data["code"], data["name"], data["address"])
            self.notify_success("Kho đã được thêm.")
        except Exception as exc:
            self.notify_error(exc)

    def add_location(self):
        warehouses = [choice_label(r, "id", "code", "name") for r in self.app.inventory_service.warehouses_for_choice()]
        dialog = FormDialog(self, "Thêm vị trí hàng", [
            ("Kho", "warehouse", warehouses),
            ("Mã vị trí (A-01-02)", "location_code"),
        ])
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["kho", "mã vị trí"])
            self.app.inventory_service.add_location(id_from_choice(data["warehouse"]), data["location_code"])
            self.notify_success("Vị trí hàng đã được thêm.")
        except Exception as exc:
            self.notify_error(exc)
