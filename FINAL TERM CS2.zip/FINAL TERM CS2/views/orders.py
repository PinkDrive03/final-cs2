import tkinter as tk
from tkinter import ttk, messagebox

from utils.validators import require_fields, positive_int, valid_date
from views.base_page import BasePage, TableMixin, FormDialog, choice_label, id_from_choice


ORDER_STATUSES = ["Chờ xử lý", "Đang xử lý", "Sẵn sàng giao", "Đang giao", "Đã giao", "Đã hủy"]
PRIORITIES = ["Thấp", "Bình thường", "Cao", "Khẩn cấp"]


class OrderPage(BasePage, TableMixin):
    def __init__(self, parent, app):
        super().__init__(
            parent,
            app,
            "Đơn hàng",
            mascot="mascot_orders_ui.png",
            mascot_tip="Chọn đơn cần làm trước nhé.\nNhấp đúp để xem chi tiết.",
        )
        self.build_filter_bar(self, [("Mã đơn", "code", None), ("Khách hàng", "customer", None), ("Trạng thái", "status", [""] + ORDER_STATUSES)])
        self.build_action_bar(self, [
            ("+  Thêm đơn hàng", self.add_order),
            ("Xử lý đơn", self.process_order),
            ("Chỉnh sửa", self.edit_order),
            ("Xóa", self.delete_order, "Danger.TButton"),
        ])
        columns = ("code", "customer", "date", "sku", "product", "quantity", "address", "priority", "status")
        headings = ("Mã đơn", "Khách hàng", "Ngày đặt", "SKU", "Sản phẩm", "Số lượng", "Địa chỉ giao", "Ưu tiên", "Trạng thái")
        self.build_table(self, columns, headings, {"address": 220, "product": 160})
        self.tree.bind("<Double-1>", self.view_detail, add="+")

    def refresh(self):
        filters = {k: v.get() for k, v in self.filter_vars.items() if v.get()}
        self.clear_table()
        for row in self.app.order_service.list_orders(filters):
            self.insert_row(row["id"], (
                row["code"], row["customer_name"], row["order_date"], row["sku"], row["product_name"],
                row["quantity"], row["delivery_address"], row["priority"], row["status"]
            ))

    def _choices(self):
        customers = [choice_label(r, "id", "name") for r in self.app.order_service.customers_for_choice()]
        products = [choice_label(r, "id", "sku", "name") for r in self.app.inventory_service.products_for_choice()]
        return customers, products

    def add_order(self):
        customers, products = self._choices()
        dialog = FormDialog(self, "Thêm đơn hàng", [
            ("Mã đơn hàng", "code"),
            ("Khách hàng", "customer", customers),
            ("Ngày đặt (YYYY-MM-DD)", "order_date"),
            ("Sản phẩm", "product", products),
            ("Số lượng", "quantity"),
            ("Địa chỉ giao", "address"),
            ("Mức ưu tiên", "priority", PRIORITIES),
        ], {"code": self.app.order_service.next_order_code(), "priority": "Bình thường"})
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["mã đơn", "khách hàng", "ngày đặt", "sản phẩm", "số lượng", "địa chỉ", "ưu tiên"])
            self.app.order_service.create_order(
                data["code"], id_from_choice(data["customer"]), valid_date(data["order_date"], "Ngày đặt"),
                id_from_choice(data["product"]), positive_int(data["quantity"], "Số lượng"),
                data["address"], data["priority"]
            )
            self.notify_success("Đơn hàng đã được tạo.")
        except Exception as exc:
            self.notify_error(exc)

    def edit_order(self):
        if not self.selected_required():
            return
        row = self.app.order_service.get_order(self.selected_id)
        customers, products = self._choices()
        dialog = FormDialog(self, "Chỉnh sửa đơn hàng", [
            ("Khách hàng", "customer", customers),
            ("Ngày đặt (YYYY-MM-DD)", "order_date"),
            ("Sản phẩm", "product", products),
            ("Số lượng", "quantity"),
            ("Địa chỉ giao", "address"),
            ("Mức ưu tiên", "priority", PRIORITIES),
            ("Trạng thái", "status", ORDER_STATUSES),
        ], {
            "customer": f"{row['customer_id']} - {row['customer_name']}",
            "order_date": row["order_date"],
            "product": f"{row['product_id']} - {row['sku']} - {row['product_name']}",
            "quantity": row["quantity"],
            "address": row["delivery_address"],
            "priority": row["priority"],
            "status": row["status"],
        })
        if not dialog.result:
            return
        try:
            data = dialog.result
            self.app.order_service.update_order(
                self.selected_id, id_from_choice(data["customer"]), valid_date(data["order_date"], "Ngày đặt"),
                id_from_choice(data["product"]), positive_int(data["quantity"], "Số lượng"),
                data["address"], data["priority"], data["status"]
            )
            self.notify_success("Đơn hàng đã được cập nhật.")
        except Exception as exc:
            self.notify_error(exc)

    def view_detail(self, _event=None):
        self.on_select()
        if not self.selected_required():
            return
        row = self.app.order_service.get_order(self.selected_id)
        messagebox.showinfo(
            "Chi tiết đơn hàng",
            f"Mã đơn: {row['code']}\nKhách hàng: {row['customer_name']}\nNgày đặt: {row['order_date']}\n"
            f"Sản phẩm: {row['sku']} - {row['product_name']}\nSố lượng: {row['quantity']}\n"
            f"Địa chỉ giao: {row['delivery_address']}\nƯu tiên: {row['priority']}\nTrạng thái: {row['status']}"
        )

    def delete_order(self):
        if not self.selected_required():
            return
        if not messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa đơn hàng này?"):
            return
        try:
            self.app.order_service.delete_order(self.selected_id)
            self.notify_success("Đơn hàng đã được xóa.")
        except Exception as exc:
            self.notify_error(exc)

    def process_order(self):
        if not self.selected_required():
            return
        try:
            self.app.order_service.process_order(self.selected_id)
            self.notify_success("Đơn hàng đã được xử lý và tồn kho đã cập nhật.")
        except Exception as exc:
            self.notify_error(exc)
