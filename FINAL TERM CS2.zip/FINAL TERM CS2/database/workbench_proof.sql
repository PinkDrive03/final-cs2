-- LOGTECH WMS - MySQL proof
-- This script is safe to run repeatedly in MySQL Workbench.

CREATE DATABASE IF NOT EXISTS logiflow_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE logiflow_db;

-- 1. Confirm the active database and available WMS tables.
SELECT DATABASE() AS active_database;
SHOW TABLES;

-- 2. Show the same inventory data used by the Tkinter application.
SELECT
    p.sku,
    p.name AS product_name,
    w.code AS warehouse_code,
    wl.code AS location_code,
    i.quantity,
    p.min_stock,
    CASE
        WHEN i.quantity = 0 THEN 'Hết hàng'
        WHEN i.quantity <= p.min_stock THEN 'Sắp hết hàng'
        ELSE 'Bình thường'
    END AS stock_status
FROM inventory AS i
JOIN products AS p ON p.id = i.product_id
JOIN warehouse_locations AS wl ON wl.id = i.location_id
JOIN warehouses AS w ON w.id = wl.warehouse_id
ORDER BY p.sku;

-- 3. Compact row-count proof for the main application tables.
SELECT 'customers' AS table_name, COUNT(*) AS row_count FROM customers
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'warehouses', COUNT(*) FROM warehouses
UNION ALL SELECT 'inventory', COUNT(*) FROM inventory
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'shipments', COUNT(*) FROM shipments
UNION ALL SELECT 'containers', COUNT(*) FROM containers
UNION ALL SELECT 'vehicles', COUNT(*) FROM vehicles
UNION ALL SELECT 'alerts', COUNT(*) FROM alerts;
