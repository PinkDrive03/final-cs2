from tkinter import ttk

from views.base_page import BasePage
from views.containers import ContainerPage
from views.shipments import ShipmentPage
from views.transport import TransportPage


class LogisticsPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Vận chuyển")
        note = ttk.Notebook(self)
        note.pack(fill="both", expand=True)

        self.shipment_page = ShipmentPage(note, app)
        self.container_page = ContainerPage(note, app)
        self.transport_page = TransportPage(note, app)

        note.add(self.shipment_page, text="Lô hàng")
        note.add(self.container_page, text="Container")
        note.add(self.transport_page, text="Phương tiện")
        self.pages = [self.shipment_page, self.container_page, self.transport_page]

    def refresh(self):
        for page in self.pages:
            page.refresh()

