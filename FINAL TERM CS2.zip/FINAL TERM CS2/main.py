import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox

import config
from data.seed_data import seed_database
from database.database_manager import DatabaseError, DatabaseManager
from services.alert_service import AlertService
from services.inventory_service import InventoryService
from services.order_service import OrderService
from views.dashboard import DashboardPage
from views.orders import OrderPage
from views.reports import ReportPage
from views.stock_warehouse import StockWarehousePage


class LogTechApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(config.APP_TITLE)
        self.geometry("1360x820")
        self.minsize(1120, 700)
        self.configure(bg="#f7f4ed")

        self._configure_style()
        self.db = DatabaseManager()
        try:
            self.db.connect()
            seed_database(self.db)
        except DatabaseError as exc:
            messagebox.showerror(
                "Lỗi kết nối MySQL",
                f"{exc}\n\nVui lòng kiểm tra MySQL và file config.py rồi chạy lại chương trình.",
            )
            self.destroy()
            sys.exit(1)

        self.alert_service = AlertService(self.db)
        self.inventory_service = InventoryService(self.db, self.alert_service)
        self.order_service = OrderService(self.db, self.inventory_service)

        self.pages = {}
        self.nav_buttons = {}
        self.current_page = None
        self._images = {}

        self._build_layout()
        self.show_page("Tổng quan")
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _configure_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure(".", font=("Segoe UI", 10), background="#f7f4ed", foreground="#2f231f")
        style.configure("App.TFrame", background="#f7f4ed")
        style.configure("Content.TFrame", background="#f7f4ed")
        style.configure("Sidebar.TFrame", background="#2f231f")
        style.configure("Brand.TLabel", font=("Segoe UI", 17, "bold"), foreground="#ffffff", background="#2f231f")
        style.configure("BrandSub.TLabel", font=("Segoe UI", 9), foreground="#cbbdb4", background="#2f231f")
        style.configure("SidebarSection.TLabel", font=("Segoe UI", 8, "bold"), foreground="#9f8f86", background="#2f231f")
        style.configure("Sidebar.TButton", font=("Segoe UI", 10, "bold"), foreground="#e9dfd8", background="#2f231f", borderwidth=0, anchor="w", padding=(15, 12))
        style.configure("SidebarActive.TButton", font=("Segoe UI", 10, "bold"), foreground="#2f231f", background="#ffb21c", borderwidth=0, anchor="w", padding=(15, 12))
        style.map("Sidebar.TButton", background=[("active", "#44332c")], foreground=[("active", "#ffffff")])
        style.map("SidebarActive.TButton", background=[("active", "#f59e0b")])

        style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"), foreground="#2f231f", background="#f7f4ed")
        style.configure("Subtitle.TLabel", font=("Segoe UI", 10), foreground="#7a6b63", background="#f7f4ed")
        style.configure("SectionTitle.TLabel", font=("Segoe UI", 12, "bold"), foreground="#2f231f", background="#ffffff")
        style.configure("Muted.TLabel", font=("Segoe UI", 9), foreground="#7a6b63", background="#ffffff")
        style.configure("Small.TLabel", font=("Segoe UI", 9, "bold"), foreground="#7a6b63", background="#ffffff")
        style.configure("Kpi.TLabel", font=("Segoe UI", 24, "bold"), foreground="#2f231f", background="#ffffff")
        style.configure("WarmValue.TLabel", font=("Segoe UI", 21, "bold"), foreground="#2f231f", background="#fff8e9")
        style.configure("KpiAccent.TLabel", font=("Segoe UI", 9, "bold"), foreground="#d56a00", background="#fff8e9")
        style.configure("Card.TFrame", background="#ffffff", relief="flat", borderwidth=0)
        style.configure("WarmCard.TFrame", background="#fff8e9", relief="flat", borderwidth=0)
        style.configure("Hero.TFrame", background="#ffffff", relief="flat", borderwidth=0)
        style.configure("HeroEyebrow.TLabel", font=("Segoe UI", 9, "bold"), foreground="#c86600", background="#fff3d6", padding=(10, 5))
        style.configure("HeroTitle.TLabel", font=("Segoe UI", 25, "bold"), foreground="#2f231f", background="#ffffff")
        style.configure("HeroBody.TLabel", font=("Segoe UI", 10), foreground="#6e5d55", background="#ffffff")
        style.configure("HeroTip.TLabel", font=("Segoe UI", 9, "bold"), foreground="#6c4610", background="#fff7e6", padding=(12, 8))
        style.configure("HeaderTip.TLabel", font=("Segoe UI", 9, "bold"), foreground="#6c4610", background="#fff7e6", padding=(12, 9))

        style.configure("TButton", font=("Segoe UI", 9, "bold"), padding=(14, 8), background="#ffb21c", foreground="#2f231f", borderwidth=0)
        style.map("TButton", background=[("active", "#f59e0b"), ("pressed", "#e88905")])
        style.configure("Primary.TButton", font=("Segoe UI", 9, "bold"), padding=(16, 9), background="#ff9f0a", foreground="#2f231f", borderwidth=0)
        style.map("Primary.TButton", background=[("active", "#ed8c00")])
        style.configure("Secondary.TButton", font=("Segoe UI", 9, "bold"), padding=(14, 8), background="#f2ece7", foreground="#4b3a32", borderwidth=0)
        style.map("Secondary.TButton", background=[("active", "#e5dbd4")])
        style.configure("Danger.TButton", font=("Segoe UI", 9, "bold"), padding=(14, 8), background="#fff0ed", foreground="#b43d2b", borderwidth=0)
        style.map("Danger.TButton", background=[("active", "#fbded8")])

        style.configure("Toolbar.TFrame", background="#ffffff")
        style.configure("Toolbar.TLabel", font=("Segoe UI", 9, "bold"), background="#ffffff", foreground="#5d4c44")
        style.configure("TEntry", padding=7, fieldbackground="#ffffff", bordercolor="#dfd5ce", lightcolor="#dfd5ce", darkcolor="#dfd5ce")
        style.configure("TCombobox", padding=7, fieldbackground="#ffffff", bordercolor="#dfd5ce", arrowsize=14)
        style.configure("TNotebook", background="#f7f4ed", borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(18, 10), background="#ebe4de", foreground="#715f56")
        style.map("TNotebook.Tab", background=[("selected", "#ffb21c")], foreground=[("selected", "#2f231f")])
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#f4eee9", foreground="#4b3a32", relief="flat", padding=8)
        style.map("Treeview.Heading", background=[("active", "#eadfd7")])
        style.configure("Treeview", font=("Segoe UI", 9), rowheight=32, fieldbackground="#ffffff", background="#ffffff", foreground="#3d302b", borderwidth=0)
        style.map("Treeview", background=[("selected", "#ffe4ad")], foreground=[("selected", "#2f231f")])
        style.configure("Vertical.TScrollbar", background="#d8cec7", troughcolor="#f7f3ef", borderwidth=0, arrowsize=12)
        style.configure("TLabelframe", background="#ffffff", bordercolor="#e7ded7", relief="solid", borderwidth=1)
        style.configure("TLabelframe.Label", background="#ffffff", foreground="#4b3a32", font=("Segoe UI", 10, "bold"))

    def _build_layout(self):
        root = ttk.Frame(self, style="App.TFrame")
        root.pack(fill="both", expand=True)

        self.sidebar = ttk.Frame(root, width=232, style="Sidebar.TFrame", padding=(18, 22))
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        brand = ttk.Frame(self.sidebar, style="Sidebar.TFrame")
        brand.pack(fill="x", pady=(0, 32))
        mark = tk.Label(brand, text="LT", font=("Segoe UI", 12, "bold"), fg="#2f231f", bg="#ffb21c", width=3, height=2)
        mark.pack(side="left", padx=(0, 10))
        brand_text = ttk.Frame(brand, style="Sidebar.TFrame")
        brand_text.pack(side="left", fill="x", expand=True)
        ttk.Label(brand_text, text="LOGTECH", style="Brand.TLabel").pack(anchor="w")
        ttk.Label(brand_text, text="WAREHOUSE SYSTEM", style="BrandSub.TLabel").pack(anchor="w")
        ttk.Label(self.sidebar, text="ĐIỀU HƯỚNG", style="SidebarSection.TLabel").pack(anchor="w", padx=8, pady=(0, 8))

        page_classes = [
            ("Tổng quan", "▦", DashboardPage),
            ("Đơn hàng", "▤", OrderPage),
            ("Tồn kho & kho", "▣", StockWarehousePage),
            ("Báo cáo", "▥", ReportPage),
        ]
        for label, icon, page_class in page_classes:
            button = ttk.Button(
                self.sidebar,
                text=f"{icon}   {label}",
                style="Sidebar.TButton",
                command=lambda name=label: self.show_page(name),
            )
            button.pack(fill="x", pady=4)
            self.nav_buttons[label] = button

        workspace = ttk.Frame(root, style="App.TFrame")
        workspace.pack(side="left", fill="both", expand=True)
        self.content = ttk.Frame(workspace, style="Content.TFrame", padding=(24, 18))
        self.content.pack(fill="both", expand=True)
        for label, _icon, page_class in page_classes:
            self.pages[label] = page_class(self.content, self)

    def show_page(self, name):
        if self.current_page:
            self.current_page.pack_forget()
        page = self.pages[name]
        page.pack(fill="both", expand=True)
        self.current_page = page
        for label, button in self.nav_buttons.items():
            button.configure(style="SidebarActive.TButton" if label == name else "Sidebar.TButton")
        page.refresh()

    def load_image(self, filename, max_width=320, max_height=320):
        key = (filename, max_width, max_height)
        if key in self._images:
            return self._images[key]
        path = Path(config.ASSET_DIR) / filename
        if not path.exists():
            return None
        source = tk.PhotoImage(file=str(path))
        factor = max(
            1,
            (source.width() + max_width - 1) // max_width,
            (source.height() + max_height - 1) // max_height,
        )
        image = source.subsample(factor, factor) if factor > 1 else source
        self._images[key] = image
        return image

    def refresh_all_pages(self):
        for page in self.pages.values():
            try:
                page.refresh()
            except Exception:
                pass

    def on_close(self):
        self.db.close()
        self.destroy()


if __name__ == "__main__":
    app = LogTechApp()
    app.mainloop()
