from tkinter import ttk

from views.base_page import BasePage
from views.inventory import InventoryPage
from views.warehouse import WarehousePage


class StockWarehousePage(BasePage):
    def __init__(self, parent, app):
        super().__init__(
            parent,
            app,
            "Tồn kho & kho hàng",
            mascot="mascot_stock_ui.png",
            mascot_tip="Chọn một SKU rồi nhập hoặc xuất.\nSố lượng sẽ cập nhật ngay.",
        )
        note = ttk.Notebook(self)
        note.pack(fill="both", expand=True)

        self.inventory_page = InventoryPage(note, app)
        self.warehouse_page = WarehousePage(note, app)
        self.inventory_page.header_block.pack_forget()
        self.warehouse_page.header_block.pack_forget()

        note.add(self.inventory_page, text="Tồn kho")
        note.add(self.warehouse_page, text="Vị trí hàng")
        self.pages = [self.inventory_page, self.warehouse_page]

    def refresh(self):
        for page in self.pages:
            page.refresh()

