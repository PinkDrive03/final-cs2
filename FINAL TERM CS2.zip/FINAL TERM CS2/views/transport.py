from utils.validators import require_fields, decimal_number
from views.base_page import BasePage, TableMixin, FormDialog


VEHICLE_STATUSES = ["Sẵn sàng", "Đã được phân công", "Đang giao hàng", "Bảo trì"]


class TransportPage(BasePage, TableMixin):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Quản lý phương tiện vận tải")
        self.build_filter_bar(self, [("Biển số", "plate", None), ("Tài xế", "driver", None), ("Trạng thái", "status", [""] + VEHICLE_STATUSES)])
        self.build_action_bar(self, [("Thêm phương tiện", self.add_vehicle), ("Chỉnh sửa", self.edit_vehicle), ("Giải phóng xe", self.release_vehicle)])
        columns = ("code", "plate", "type", "capacity", "driver", "status", "shipment")
        headings = ("Mã phương tiện", "Biển số", "Loại xe", "Tải trọng", "Tài xế", "Trạng thái", "Lô hàng đang phụ trách")
        self.build_table(self, columns, headings, {"driver": 140})

    def refresh(self):
        filters = {k: v.get() for k, v in self.filter_vars.items() if v.get()}
        self.clear_table()
        for row in self.app.transport_service.list_vehicles(filters):
            self.tree.insert("", "end", iid=row["id"], values=(
                row["code"], row["plate"], row["vehicle_type"], row["capacity"], row["driver"], row["status"], row["shipment_code"] or ""
            ))

    def _fields(self):
        return [
            ("Biển số", "plate"),
            ("Loại xe", "vehicle_type"),
            ("Tải trọng", "capacity"),
            ("Tài xế", "driver"),
            ("Trạng thái", "status", VEHICLE_STATUSES),
        ]

    def add_vehicle(self):
        dialog = FormDialog(self, "Thêm phương tiện", [("Mã phương tiện", "code")] + self._fields(), {
            "code": self.app.transport_service.next_vehicle_code(),
            "status": "Sẵn sàng",
        })
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["mã phương tiện", "biển số", "loại xe", "tải trọng", "tài xế", "trạng thái"])
            self.app.transport_service.add_vehicle(
                data["code"], data["plate"], data["vehicle_type"], decimal_number(data["capacity"], "Tải trọng"),
                data["driver"], data["status"]
            )
            self.notify_success("Phương tiện đã được thêm.")
        except Exception as exc:
            self.notify_error(exc)

    def edit_vehicle(self):
        if not self.selected_required():
            return
        row = self.db.fetch_one("SELECT * FROM vehicles WHERE id=%s", (self.selected_id,))
        dialog = FormDialog(self, "Chỉnh sửa phương tiện", self._fields(), row)
        if not dialog.result:
            return
        try:
            data = dialog.result
            self.app.transport_service.update_vehicle(
                self.selected_id, data["plate"], data["vehicle_type"], decimal_number(data["capacity"], "Tải trọng"),
                data["driver"], data["status"]
            )
            self.notify_success("Phương tiện đã được cập nhật.")
        except Exception as exc:
            self.notify_error(exc)

    def release_vehicle(self):
        if not self.selected_required():
            return
        try:
            self.app.transport_service.release_vehicle(self.selected_id)
            self.notify_success("Xe đã được giải phóng và chuyển về Sẵn sàng.")
        except Exception as exc:
            self.notify_error(exc)
