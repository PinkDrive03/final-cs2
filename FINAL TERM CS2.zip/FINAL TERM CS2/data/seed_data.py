import os
import sys
from datetime import date, timedelta

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from database.database_manager import DatabaseManager, DatabaseError
from services.alert_service import AlertService
from services.inventory_service import InventoryService


TARGET_DEMO_ORDERS = 500


def ensure_order_volume(db: DatabaseManager, target=TARGET_DEMO_ORDERS):
    current = db.fetch_one("SELECT COUNT(*) AS total FROM orders")["total"]
    if current >= target:
        return 0

    customer_rows = db.fetch_all("SELECT id FROM customers ORDER BY id")
    product_rows = db.fetch_all("SELECT id FROM products WHERE sku <> 'SKU001' ORDER BY sku")
    if not customer_rows or not product_rows:
        return 0

    today = date.today()
    statuses = ["Chờ xử lý", "Đang xử lý", "Sẵn sàng giao", "Đang giao", "Đã giao", "Đã hủy"]
    priorities = ["Bình thường", "Cao", "Thấp", "Khẩn cấp"]
    created = 0
    number = 1
    while current + created < target:
        code = f"ORD{number:04d}"
        number += 1
        if db.fetch_one("SELECT id FROM orders WHERE code=%s", (code,)):
            continue
        customer_id = customer_rows[(number - 2) % len(customer_rows)]["id"]
        product_id = product_rows[(number - 2) % len(product_rows)]["id"]
        order_id = db.insert(
            """
            INSERT INTO orders (code,customer_id,order_date,delivery_address,priority,status)
            VALUES (%s,%s,%s,%s,%s,%s)
            """,
            (
                code,
                customer_id,
                today - timedelta(days=(number % 90)),
                f"Điểm giao demo {number}, TP.HCM",
                priorities[number % len(priorities)],
                statuses[number % len(statuses)],
            ),
        )
        db.insert(
            "INSERT INTO order_items (order_id,product_id,quantity) VALUES (%s,%s,%s)",
            (order_id, product_id, 1 + (number % 12)),
        )
        created += 1
    db.commit()
    return created


def seed_database(db: DatabaseManager):
    db.connect()
    existing = db.fetch_one("SELECT COUNT(*) AS total FROM products")
    if existing and existing["total"] >= 30:
        created_orders = ensure_order_volume(db)
        return created_orders > 0

    customers = [("CUST001", "ABC Store", "0901000001", "12 Nguyễn Huệ, TP.HCM")]
    customers += [
        (f"CUST{i:03d}", name, f"0901{i:06d}", address)
        for i, (name, address) in enumerate(
            [
                ("Minh Long Trading", "Quận 1, TP.HCM"),
                ("An Phát Retail", "Thủ Đức, TP.HCM"),
                ("Bình Minh Mart", "Dĩ An, Bình Dương"),
                ("Đại Nam Shop", "Biên Hòa, Đồng Nai"),
                ("Sài Gòn Tech", "Quận 7, TP.HCM"),
                ("Hải Đăng Co.", "Tân Bình, TP.HCM"),
                ("Vạn Lợi Store", "Thuận An, Bình Dương"),
                ("Hoàng Gia Market", "Quận 5, TP.HCM"),
                ("Tân Phú Supply", "Tân Phú, TP.HCM"),
                ("Đồng Tâm Retail", "Long Thành, Đồng Nai"),
                ("Nam Việt Shop", "Gò Vấp, TP.HCM"),
                ("Phúc Khang Trading", "Quận 10, TP.HCM"),
                ("Gia Hưng Mart", "Bến Cát, Bình Dương"),
                ("Thiên Ân Store", "Nhơn Trạch, Đồng Nai"),
                ("Việt Nhật Co.", "Quận 3, TP.HCM"),
                ("An Khang Retail", "Quận 12, TP.HCM"),
                ("Hòa Bình Supply", "Tân Uyên, Bình Dương"),
                ("Kim Sơn Market", "Trảng Bom, Đồng Nai"),
                ("Thành Công Shop", "Bình Thạnh, TP.HCM"),
            ],
            start=2,
        )
    ]
    db.execute(
        "INSERT IGNORE INTO customers (code,name,phone,address) VALUES (%s,%s,%s,%s)",
        customers,
        many=True,
    ).close()

    warehouses = [
        ("WH01", "Kho TP.HCM", "Khu công nghiệp Tân Bình, TP.HCM"),
        ("WH02", "Kho Bình Dương", "Khu công nghiệp VSIP, Bình Dương"),
        ("WH03", "Kho Đồng Nai", "Khu công nghiệp Amata, Đồng Nai"),
    ]
    db.execute("INSERT IGNORE INTO warehouses (code,name,address) VALUES (%s,%s,%s)", warehouses, many=True).close()
    db.commit()

    wh_rows = db.fetch_all("SELECT id, code FROM warehouses ORDER BY code")
    for wh in wh_rows:
        locations = []
        for area in ["A", "B"]:
            for rack in range(1, 4):
                for bin_no in range(1, 3):
                    code = f"{area}-{rack:02d}-{bin_no:02d}"
                    locations.append((wh["id"], code, area, f"{rack:02d}", f"{bin_no:02d}"))
        db.execute(
            """
            INSERT IGNORE INTO warehouse_locations (warehouse_id,code,area,rack,bin)
            VALUES (%s,%s,%s,%s,%s)
            """,
            locations,
            many=True,
        ).close()
    db.commit()

    product_names = [
        "Laptop", "Màn hình 24 inch", "Bàn phím cơ", "Chuột không dây", "Máy in laser",
        "Router WiFi", "Ổ cứng SSD", "RAM 16GB", "Tai nghe văn phòng", "Webcam HD",
        "Máy quét mã vạch", "Máy POS", "Máy chấm công", "Camera IP", "Switch mạng",
        "UPS 1000VA", "Máy tính bảng", "Điện thoại kho", "Máy in tem", "Giấy in tem",
        "Thùng carton S", "Thùng carton M", "Thùng carton L", "Màng PE", "Băng keo",
        "Pallet nhựa", "Kệ mini", "Pin dự phòng", "Cáp mạng", "Adapter nguồn",
    ]
    products = []
    for idx, name in enumerate(product_names, start=1):
        min_stock = 25 if idx == 1 else 8 + (idx % 6) * 3
        products.append((f"SKU{idx:03d}", name, "cái", min_stock))
    db.execute(
        "INSERT IGNORE INTO products (sku,name,unit,min_stock) VALUES (%s,%s,%s,%s)",
        products,
        many=True,
    ).close()
    db.commit()

    product_rows = db.fetch_all("SELECT id, sku FROM products ORDER BY sku")
    loc_rows = db.fetch_all("SELECT id FROM warehouse_locations ORDER BY id")
    inventory = []
    for idx, product in enumerate(product_rows):
        qty = 50 if product["sku"] == "SKU001" else 18 + (idx * 7) % 70
        inventory.append((product["id"], loc_rows[idx % len(loc_rows)]["id"], qty))
    db.execute(
        "INSERT IGNORE INTO inventory (product_id,location_id,quantity) VALUES (%s,%s,%s)",
        inventory,
        many=True,
    ).close()
    db.commit()

    customer_rows = db.fetch_all("SELECT id FROM customers ORDER BY id")
    product_no_laptop = db.fetch_all("SELECT id FROM products WHERE sku <> 'SKU001' ORDER BY sku")
    today = date.today()
    statuses = ["Chờ xử lý", "Đang xử lý", "Sẵn sàng giao", "Đang giao", "Đã giao"]
    priorities = ["Bình thường", "Cao", "Thấp", "Khẩn cấp"]
    for i in range(1, 41):
        code = f"ORD{i:04d}"
        if db.fetch_one("SELECT id FROM orders WHERE code=%s", (code,)):
            continue
        customer_id = customer_rows[(i - 1) % len(customer_rows)]["id"]
        product_id = product_no_laptop[(i - 1) % len(product_no_laptop)]["id"]
        order_id = db.insert(
            """
            INSERT INTO orders (code,customer_id,order_date,delivery_address,priority,status)
            VALUES (%s,%s,%s,%s,%s,%s)
            """,
            (
                code,
                customer_id,
                today - timedelta(days=i % 20),
                f"Điểm giao {i}, TP.HCM",
                priorities[i % len(priorities)],
                statuses[i % len(statuses)],
            ),
        )
        db.insert("INSERT INTO order_items (order_id,product_id,quantity) VALUES (%s,%s,%s)", (order_id, product_id, 3 + (i % 9)))
    db.commit()

    containers = []
    for i in range(1, 11):
        containers.append((
            f"CONT{i:04d}",
            ["20GP", "40GP", "40HC"][i % 3],
            "Kho TP.HCM" if i < 6 else "Cảng Cát Lái",
            "Cát Lái",
            "Hải Phòng" if i % 2 else "Đà Nẵng",
            today - timedelta(days=i),
            today + timedelta(days=2 + i),
            "Rỗng",
        ))
    db.execute(
        """
        INSERT IGNORE INTO containers
        (code,type,current_location,port_from,port_to,departure_date,eta,status)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        """,
        containers,
        many=True,
    ).close()

    vehicles = []
    for i in range(1, 11):
        vehicles.append((
            f"VH{i:04d}",
            f"51C-{10000+i}",
            ["Xe tải 1.5 tấn", "Xe tải 5 tấn", "Đầu kéo"][i % 3],
            1.5 if i % 3 == 1 else (5.0 if i % 3 == 2 else 20.0),
            f"Tài xế {i}",
            "Sẵn sàng" if i <= 7 else "Bảo trì",
        ))
    db.execute(
        "INSERT IGNORE INTO vehicles (code,plate,vehicle_type,capacity,driver,status) VALUES (%s,%s,%s,%s,%s,%s)",
        vehicles,
        many=True,
    ).close()
    db.commit()

    ready_orders = db.fetch_all("SELECT id, code FROM orders WHERE status IN ('Sẵn sàng giao','Đang giao','Đã giao') ORDER BY id LIMIT 15")
    container_rows = db.fetch_all("SELECT id FROM containers ORDER BY id")
    vehicle_rows = db.fetch_all("SELECT id FROM vehicles WHERE status='Sẵn sàng' ORDER BY id")
    for i, order in enumerate(ready_orders, start=1):
        code = f"SHP{i:04d}"
        if db.fetch_one("SELECT id FROM shipments WHERE code=%s OR order_id=%s", (code, order["id"])):
            continue
        status = "Đang vận chuyển" if i <= 5 else ("Đã giao" if i <= 10 else "Sẵn sàng")
        expected = today - timedelta(days=1) if i == 5 else today + timedelta(days=3 + i)
        shipment_id = db.insert(
            """
            INSERT INTO shipments
            (code,order_id,origin,destination,departure_date,expected_arrival,actual_arrival,container_id,vehicle_id,status)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """,
            (
                code,
                order["id"],
                "Kho TP.HCM",
                f"Điểm giao {i}, TP.HCM",
                today - timedelta(days=i),
                expected,
                today - timedelta(days=1) if status == "Đã giao" else None,
                container_rows[i - 1]["id"] if i <= len(container_rows) else None,
                vehicle_rows[(i - 1) % len(vehicle_rows)]["id"] if i <= len(vehicle_rows) else None,
                status,
            ),
        )
        if i <= len(container_rows):
            db.execute("UPDATE containers SET shipment_id=%s, status=%s WHERE id=%s", (shipment_id, "Đang vận chuyển" if status == "Đang vận chuyển" else "Đã đóng hàng", container_rows[i - 1]["id"])).close()
        if i <= len(vehicle_rows) and status != "Đã giao":
            db.execute("UPDATE vehicles SET status=%s, current_shipment_id=%s WHERE id=%s", ("Đang giao hàng" if status == "Đang vận chuyển" else "Đã được phân công", shipment_id, vehicle_rows[(i - 1) % len(vehicle_rows)]["id"])).close()
    db.commit()

    ensure_order_volume(db)

    alert_service = AlertService(db)
    inventory_service = InventoryService(db, alert_service)
    for product in product_rows:
        inventory_service.evaluate_stock(product["id"])
    alert_service.check_late_shipments()
    alert_service.check_container_eta()
    db.commit()
    return True


if __name__ == "__main__":
    manager = DatabaseManager()
    try:
        created = seed_database(manager)
        print("Đã tạo dữ liệu demo." if created else "Dữ liệu demo đã tồn tại.")
    except DatabaseError as exc:
        print(f"Lỗi kết nối MySQL: {exc}")
        print("Hãy kiểm tra DB_USER/DB_PASSWORD trong config.py hoặc biến môi trường LOGTECH_DB_PASSWORD.")
