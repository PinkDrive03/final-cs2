from datetime import date

from utils.helpers import next_code


class ShipmentService:
    def __init__(self, db, alert_service):
        self.db = db
        self.alert_service = alert_service

    def list_shipments(self, filters=None):
        filters = filters or {}
        sql = """
            SELECT s.id, s.code, o.code AS order_code, s.origin, s.destination,
                   s.departure_date, s.expected_arrival, s.actual_arrival,
                   c.code AS container_code, v.plate AS vehicle_plate, s.status
            FROM shipments s
            JOIN orders o ON o.id=s.order_id
            LEFT JOIN containers c ON c.id=s.container_id
            LEFT JOIN vehicles v ON v.id=s.vehicle_id
            WHERE 1=1
        """
        params = []
        if filters.get("keyword"):
            sql += " AND (s.code LIKE %s OR o.code LIKE %s OR s.destination LIKE %s OR s.status LIKE %s)"
            kw = f"%{filters['keyword']}%"
            params += [kw, kw, kw, kw]
        if filters.get("code"):
            sql += " AND s.code LIKE %s"
            params.append(f"%{filters['code']}%")
        if filters.get("order_code"):
            sql += " AND o.code LIKE %s"
            params.append(f"%{filters['order_code']}%")
        if filters.get("destination"):
            sql += " AND s.destination LIKE %s"
            params.append(f"%{filters['destination']}%")
        if filters.get("status"):
            sql += " AND s.status=%s"
            params.append(filters["status"])
        sql += " ORDER BY s.id DESC"
        return self.db.fetch_all(sql, tuple(params))

    def orders_ready_for_shipment(self):
        return self.db.fetch_all(
            """
            SELECT o.id, o.code, c.name AS customer_name, o.delivery_address
            FROM orders o
            JOIN customers c ON c.id=o.customer_id
            LEFT JOIN shipments s ON s.order_id=o.id
            WHERE o.status='Sẵn sàng giao' AND s.id IS NULL
            ORDER BY o.id DESC
            """
        )

    def create_from_order(self, code, order_id, origin, destination, departure_date, expected_arrival):
        order = self.db.fetch_one("SELECT status FROM orders WHERE id=%s", (order_id,))
        if not order:
            raise ValueError("Đơn hàng không tồn tại.")
        if order["status"] != "Sẵn sàng giao":
            raise ValueError("Chỉ tạo lô hàng cho đơn Sẵn sàng giao.")
        if self.db.fetch_one("SELECT id FROM shipments WHERE order_id=%s", (order_id,)):
            raise ValueError("Đơn hàng này đã có lô hàng.")
        if self.db.fetch_one("SELECT id FROM shipments WHERE code=%s", (code,)):
            raise ValueError("Mã lô hàng đã tồn tại.")
        shipment_id = self.db.insert(
            """
            INSERT INTO shipments
            (code, order_id, origin, destination, departure_date, expected_arrival, status)
            VALUES (%s,%s,%s,%s,%s,%s,'Chờ xử lý')
            """,
            (code, order_id, origin, destination, departure_date, expected_arrival),
        )
        self.db.commit()
        return shipment_id

    def update_shipment(self, shipment_id, origin, destination, departure_date, expected_arrival, actual_arrival, status):
        self.db.execute(
            """
            UPDATE shipments SET origin=%s, destination=%s, departure_date=%s,
            expected_arrival=%s, actual_arrival=%s, status=%s WHERE id=%s
            """,
            (origin, destination, departure_date, expected_arrival, actual_arrival or None, status, shipment_id),
        ).close()
        self._apply_status_effects(shipment_id, status)
        self.db.commit()

    def available_containers(self):
        return self.db.fetch_all(
            "SELECT id, code, type FROM containers WHERE shipment_id IS NULL OR status IN ('Rỗng','Đã dỡ hàng') ORDER BY code"
        )

    def available_vehicles(self):
        return self.db.fetch_all("SELECT id, plate, driver FROM vehicles WHERE status='Sẵn sàng' ORDER BY plate")

    def assign_container(self, shipment_id, container_id):
        if not self.db.fetch_one("SELECT id FROM shipments WHERE id=%s", (shipment_id,)):
            raise ValueError("Lô hàng không tồn tại.")
        self.db.execute("UPDATE shipments SET container_id=%s WHERE id=%s", (container_id, shipment_id)).close()
        self.db.execute(
            "UPDATE containers SET shipment_id=%s, status='Đang đóng hàng' WHERE id=%s",
            (shipment_id, container_id),
        ).close()
        self.db.commit()

    def assign_vehicle(self, shipment_id, vehicle_id):
        vehicle = self.db.fetch_one("SELECT status FROM vehicles WHERE id=%s", (vehicle_id,))
        if not vehicle or vehicle["status"] != "Sẵn sàng":
            raise ValueError("Chỉ được gán xe có trạng thái Sẵn sàng.")
        self.db.execute("UPDATE shipments SET vehicle_id=%s WHERE id=%s", (vehicle_id, shipment_id)).close()
        self.db.execute(
            "UPDATE vehicles SET status='Đã được phân công', current_shipment_id=%s WHERE id=%s",
            (shipment_id, vehicle_id),
        ).close()
        self.db.commit()

    def update_status(self, shipment_id, status):
        self.db.execute("UPDATE shipments SET status=%s WHERE id=%s", (status, shipment_id)).close()
        self._apply_status_effects(shipment_id, status)
        self.db.commit()

    def _apply_status_effects(self, shipment_id, status):
        shipment = self.db.fetch_one("SELECT order_id, vehicle_id, container_id, code FROM shipments WHERE id=%s", (shipment_id,))
        if not shipment:
            return
        if status == "Sẵn sàng":
            if shipment["container_id"]:
                self.db.execute("UPDATE containers SET status='Đã đóng hàng' WHERE id=%s", (shipment["container_id"],)).close()
        elif status == "Đang vận chuyển":
            self.db.execute("UPDATE orders SET status='Đang giao' WHERE id=%s", (shipment["order_id"],)).close()
            if shipment["vehicle_id"]:
                self.db.execute("UPDATE vehicles SET status='Đang giao hàng' WHERE id=%s", (shipment["vehicle_id"],)).close()
            if shipment["container_id"]:
                self.db.execute("UPDATE containers SET status='Đang vận chuyển' WHERE id=%s", (shipment["container_id"],)).close()
        elif status == "Đã giao":
            self.db.execute("UPDATE shipments SET actual_arrival=%s WHERE id=%s", (date.today(), shipment_id)).close()
            self.db.execute("UPDATE orders SET status='Đã giao' WHERE id=%s", (shipment["order_id"],)).close()
            if shipment["vehicle_id"]:
                self.db.execute(
                    "UPDATE vehicles SET status='Sẵn sàng', current_shipment_id=NULL WHERE id=%s",
                    (shipment["vehicle_id"],),
                ).close()
            if shipment["container_id"]:
                self.db.execute("UPDATE containers SET status='Đã đến' WHERE id=%s", (shipment["container_id"],)).close()
            self.alert_service.resolve_issue(f"shipment_late:{shipment_id}")
        elif status == "Trễ":
            self.alert_service.create_unique(
                "Lô hàng giao trễ",
                "shipments",
                shipment_id,
                f"shipment_late:{shipment_id}",
                f"Lô hàng {shipment['code']} đã bị trễ.",
                "Nghiêm trọng",
            )

    def next_shipment_code(self):
        return next_code(self.db, "shipments", "SHP")

