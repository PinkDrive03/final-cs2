from utils.validators import require_fields, positive_int, non_negative_int
from views.base_page import BasePage, TableMixin, FormDialog, choice_label, id_from_choice


STOCK_STATUSES = ["Bình thường", "Sắp hết hàng", "Hết hàng"]


class InventoryPage(BasePage, TableMixin):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Quản lý tồn kho")
        self.build_filter_bar(self, [("SKU/Tên", "keyword", None), ("Kho", "warehouse", None), ("Trạng thái", "status", [""] + STOCK_STATUSES)])
        self.build_action_bar(self, [
            ("+  Thêm sản phẩm", self.add_product),
            ("Nhập kho", self.import_stock),
            ("Xuất kho", self.export_stock),
            ("Chỉnh sửa", self.edit_inventory),
        ])
        columns = ("sku", "name", "warehouse", "location", "quantity", "min_stock", "status")
        headings = ("SKU", "Tên sản phẩm", "Kho", "Vị trí", "Tồn hiện tại", "Mức tối thiểu", "Trạng thái")
        self.build_table(self, columns, headings, {"name": 180})

    def refresh(self):
        filters = {k: v.get() for k, v in self.filter_vars.items() if v.get()}
        self.clear_table()
        for row in self.app.inventory_service.list_inventory(filters):
            self.insert_row(row["id"], (
                row["sku"], row["product_name"], row["warehouse_code"], row["location_code"],
                row["quantity"], row["min_stock"], row["stock_status"]
            ))

    def add_product(self):
        locations = [choice_label(r, "id", "warehouse_code", "code") for r in self.app.inventory_service.locations_for_choice()]
        dialog = FormDialog(self, "Thêm sản phẩm", [
            ("SKU", "sku"),
            ("Tên sản phẩm", "name"),
            ("Đơn vị", "unit"),
            ("Mức tồn tối thiểu", "min_stock"),
            ("Vị trí lưu trữ", "location", locations),
            ("Tồn ban đầu", "quantity"),
        ], {"unit": "cái", "quantity": "0"})
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["SKU", "tên sản phẩm", "đơn vị", "mức tối thiểu", "vị trí", "tồn ban đầu"])
            self.app.inventory_service.add_product(
                data["sku"], data["name"], data["unit"], non_negative_int(data["min_stock"], "Mức tồn tối thiểu"),
                id_from_choice(data["location"]), non_negative_int(data["quantity"], "Tồn ban đầu")
            )
            self.notify_success("Sản phẩm đã được thêm.")
        except Exception as exc:
            self.notify_error(exc)

    def edit_inventory(self):
        if not self.selected_required():
            return
        row = self.db.fetch_one(
            """
            SELECT i.id, p.name, p.min_stock, i.quantity
            FROM inventory i JOIN products p ON p.id=i.product_id
            WHERE i.id=%s
            """,
            (self.selected_id,),
        )
        dialog = FormDialog(self, "Chỉnh sửa tồn kho", [
            ("Tên sản phẩm", "name"),
            ("Mức tồn tối thiểu", "min_stock"),
            ("Tồn hiện tại", "quantity"),
        ], row)
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["tên sản phẩm", "mức tối thiểu", "tồn hiện tại"])
            self.app.inventory_service.update_inventory(
                self.selected_id, data["name"], non_negative_int(data["min_stock"], "Mức tồn tối thiểu"),
                non_negative_int(data["quantity"], "Tồn hiện tại")
            )
            self.notify_success("Tồn kho đã được cập nhật.")
        except Exception as exc:
            self.notify_error(exc)

    def import_stock(self):
        self._adjust("Nhập kho", 1)

    def export_stock(self):
        self._adjust("Xuất kho", -1)

    def _adjust(self, title, sign):
        if not self.selected_required():
            return
        dialog = FormDialog(self, title, [("Số lượng", "quantity")])
        if not dialog.result:
            return
        try:
            quantity = positive_int(dialog.result["quantity"], "Số lượng")
            self.app.inventory_service.adjust_stock(self.selected_id, sign * quantity)
            self.notify_success(f"{title} thành công.")
        except Exception as exc:
            self.notify_error(exc)

