"""Run the open LOGTECH WMS proof query once MySQL Workbench is ready."""

import grt
import mforms


_attempts = 0
_proof_sql = ""


def _run_proof_query():
    global _attempts
    _attempts += 1

    try:
        if grt.root.wb.sqlEditors:
            editor = grt.root.wb.sqlEditors[-1]
            if editor.isConnected and _proof_sql:
                query_editor = editor.addQueryEditor()
                query_editor.replaceContents(_proof_sql)
                editor.defaultSchema = "logiflow_db"
                editor.executeScriptAndOutputToGrid(_proof_sql)
                grt.log_info(
                    "LOGTECH WMS", "Proof query executed in Result Grid"
                )
                return False
    except Exception as exc:
        grt.log_warning("LOGTECH WMS", "Waiting for SQL Editor: %s" % exc)

    return _attempts < 30


_timer = mforms.Utilities.add_timeout(1.0, _run_proof_query)
