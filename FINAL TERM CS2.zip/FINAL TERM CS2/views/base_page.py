import tkinter as tk
from tkinter import ttk, messagebox


ORANGE = "#f97316"
LIGHT_ORANGE = "#fff8e9"
DARK = "#2f231f"


class BasePage(ttk.Frame):
    def __init__(self, parent, app, title, subtitle="", mascot=None, mascot_tip=""):
        super().__init__(parent, style="Content.TFrame")
        self.app = app
        self.title = title
        self.selected_id = None
        self.header_block = ttk.Frame(self, style="Content.TFrame")
        self.header_block.pack(fill="x", pady=(0, 12))
        self.header = ttk.Label(self.header_block, text=title, style="Title.TLabel")
        if mascot:
            image = self.app.load_image(mascot, max_width=140, max_height=140)
            if image:
                helper = ttk.Frame(self.header_block, style="Content.TFrame")
                helper.pack(side="right")
                if mascot_tip:
                    ttk.Label(
                        helper,
                        text=mascot_tip,
                        style="HeaderTip.TLabel",
                        justify="left",
                    ).pack(side="left", padx=(0, 10))
                self.mascot_label = tk.Label(helper, image=image, bg="#f7f4ed", borderwidth=0)
                self.mascot_label.pack(side="left")
                self.header.pack(side="left", anchor="n", pady=(28, 0))
            else:
                self.header.pack(side="left", anchor="w")
        else:
            self.header.pack(side="left", anchor="w")
        if subtitle:
            ttk.Label(self.header_block, text=subtitle, style="Subtitle.TLabel").pack(side="left", padx=(14, 0))

    @property
    def db(self):
        return self.app.db

    def refresh(self):
        raise NotImplementedError

    def notify_success(self, text):
        messagebox.showinfo("Thành công", text)
        self.app.refresh_all_pages()

    def notify_error(self, exc):
        messagebox.showerror("Lỗi", str(exc))

    def selected_required(self, text="Vui lòng chọn một dòng."):
        if not self.selected_id:
            messagebox.showwarning("Thông báo", text)
            return False
        return True


class TableMixin:
    def build_filter_bar(self, parent, fields):
        bar = ttk.Frame(parent, style="Toolbar.TFrame", padding=(14, 11))
        bar.pack(fill="x", pady=(0, 10))
        self.filter_vars = {}
        for label, key, values in fields:
            ttk.Label(bar, text=label, style="Toolbar.TLabel").pack(side="left", padx=(0, 6))
            var = tk.StringVar()
            if values:
                widget = ttk.Combobox(bar, textvariable=var, values=values, width=18, state="readonly")
            else:
                widget = ttk.Entry(bar, textvariable=var, width=18)
            widget.pack(side="left", padx=(0, 12))
            self.filter_vars[key] = var
        ttk.Button(bar, text="Tìm kiếm", style="Primary.TButton", command=self.refresh).pack(side="left", padx=4)
        ttk.Button(bar, text="Xóa lọc", style="Secondary.TButton", command=self.clear_filters).pack(side="left", padx=4)

    def build_table(self, parent, columns, headings, widths=None):
        frame = ttk.Frame(parent, style="Card.TFrame", padding=1)
        frame.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(frame, columns=columns, show="headings", height=14)
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        for index, column in enumerate(columns):
            self.tree.heading(column, text=headings[index])
            self.tree.column(column, width=(widths or {}).get(column, 120), anchor="w")
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.tag_configure("odd", background="#fffaf2")
        self.tree.tag_configure("even", background="#ffffff")

    def build_action_bar(self, parent, actions):
        bar = ttk.Frame(parent, style="Content.TFrame")
        bar.pack(fill="x", pady=(0, 10))
        for index, action in enumerate(actions):
            text, command = action[:2]
            style = action[2] if len(action) > 2 else ("Primary.TButton" if index == 0 else "Secondary.TButton")
            ttk.Button(bar, text=text, style=style, command=command).pack(side="left", padx=(0, 8))

    def on_select(self, _event=None):
        item = self.tree.focus()
        if item:
            self.selected_id = int(item)

    def clear_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.selected_id = None

    def insert_row(self, iid, values):
        row_number = len(self.tree.get_children())
        self.tree.insert("", "end", iid=iid, values=values, tags=("even" if row_number % 2 == 0 else "odd",))

    def clear_filters(self):
        for var in getattr(self, "filter_vars", {}).values():
            var.set("")
        self.refresh()


class FormDialog(tk.Toplevel):
    def __init__(self, parent, title, fields, initial=None):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.configure(bg="#f7f4ed")
        self.result = None
        self.vars = {}
        initial = initial or {}
        body = ttk.Frame(self, style="Card.TFrame", padding=20)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=title, style="SectionTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        for row, field in enumerate(fields):
            label, key = field[0], field[1]
            values = field[2] if len(field) > 2 else None
            ttk.Label(body, text=label, style="Small.TLabel").grid(row=row + 1, column=0, sticky="w", pady=5, padx=(0, 12))
            var = tk.StringVar(value="" if initial.get(key) is None else str(initial.get(key)))
            if values:
                widget = ttk.Combobox(body, textvariable=var, values=values, width=34, state="readonly")
            else:
                widget = ttk.Entry(body, textvariable=var, width=36)
            widget.grid(row=row + 1, column=1, sticky="ew", pady=5)
            self.vars[key] = var
        buttons = ttk.Frame(body, style="Card.TFrame")
        buttons.grid(row=len(fields) + 1, column=0, columnspan=2, sticky="e", pady=(16, 0))
        ttk.Button(buttons, text="Lưu thay đổi", style="Primary.TButton", command=self.accept).pack(side="left", padx=4)
        ttk.Button(buttons, text="Hủy", style="Secondary.TButton", command=self.destroy).pack(side="left", padx=4)
        self.transient(parent)
        self.grab_set()
        self.wait_visibility()
        self.focus()

    def accept(self):
        self.result = {key: var.get().strip() for key, var in self.vars.items()}
        self.destroy()


def choice_label(row, *keys):
    return " - ".join(str(row[k]) for k in keys if row.get(k) is not None)


def id_from_choice(value):
    return int(value.split(" - ", 1)[0])
