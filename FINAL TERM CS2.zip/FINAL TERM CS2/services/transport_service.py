from utils.helpers import next_code


class TransportService:
    def __init__(self, db):
        self.db = db

    def list_containers(self, filters=None):
        filters = filters or {}
        sql = """
            SELECT c.id, c.code, c.type, s.code AS shipment_code, c.current_location,
                   c.port_from, c.port_to, c.departure_date, c.eta, c.status
            FROM containers c
            LEFT JOIN shipments s ON s.id=c.shipment_id
            WHERE 1=1
        """
        params = []
        if filters.get("keyword"):
            sql += " AND (c.code LIKE %s OR c.port_from LIKE %s OR c.port_to LIKE %s OR c.status LIKE %s)"
            kw = f"%{filters['keyword']}%"
            params += [kw, kw, kw, kw]
        if filters.get("code"):
            sql += " AND c.code LIKE %s"
            params.append(f"%{filters['code']}%")
        if filters.get("port"):
            sql += " AND (c.port_from LIKE %s OR c.port_to LIKE %s)"
            kw = f"%{filters['port']}%"
            params += [kw, kw]
        if filters.get("status"):
            sql += " AND c.status=%s"
            params.append(filters["status"])
        sql += " ORDER BY c.code"
        return self.db.fetch_all(sql, tuple(params))

    def add_container(self, code, type_, current_location, port_from, port_to, departure_date, eta, status):
        if self.db.fetch_one("SELECT id FROM containers WHERE code=%s", (code,)):
            raise ValueError("Mã container đã tồn tại.")
        self.db.insert(
            """
            INSERT INTO containers
            (code,type,current_location,port_from,port_to,departure_date,eta,status)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
            """,
            (code, type_, current_location, port_from, port_to, departure_date, eta, status),
        )
        self.db.commit()

    def update_container(self, container_id, type_, current_location, port_from, port_to, departure_date, eta, status):
        self.db.execute(
            """
            UPDATE containers SET type=%s,current_location=%s,port_from=%s,port_to=%s,
            departure_date=%s,eta=%s,status=%s WHERE id=%s
            """,
            (type_, current_location, port_from, port_to, departure_date, eta, status, container_id),
        ).close()
        self.db.commit()

    def set_container_status(self, container_id, status):
        self.db.execute("UPDATE containers SET status=%s WHERE id=%s", (status, container_id)).close()
        self.db.commit()

    def list_vehicles(self, filters=None):
        filters = filters or {}
        sql = """
            SELECT v.id, v.code, v.plate, v.vehicle_type, v.capacity, v.driver,
                   v.status, s.code AS shipment_code
            FROM vehicles v
            LEFT JOIN shipments s ON s.id=v.current_shipment_id
            WHERE 1=1
        """
        params = []
        if filters.get("keyword"):
            sql += " AND (v.plate LIKE %s OR v.driver LIKE %s OR v.status LIKE %s)"
            kw = f"%{filters['keyword']}%"
            params += [kw, kw, kw]
        if filters.get("plate"):
            sql += " AND v.plate LIKE %s"
            params.append(f"%{filters['plate']}%")
        if filters.get("driver"):
            sql += " AND v.driver LIKE %s"
            params.append(f"%{filters['driver']}%")
        if filters.get("status"):
            sql += " AND v.status=%s"
            params.append(filters["status"])
        sql += " ORDER BY v.plate"
        return self.db.fetch_all(sql, tuple(params))

    def add_vehicle(self, code, plate, vehicle_type, capacity, driver, status):
        if self.db.fetch_one("SELECT id FROM vehicles WHERE code=%s OR plate=%s", (code, plate)):
            raise ValueError("Mã phương tiện hoặc biển số đã tồn tại.")
        self.db.insert(
            """
            INSERT INTO vehicles (code,plate,vehicle_type,capacity,driver,status)
            VALUES (%s,%s,%s,%s,%s,%s)
            """,
            (code, plate, vehicle_type, capacity, driver, status),
        )
        self.db.commit()

    def update_vehicle(self, vehicle_id, plate, vehicle_type, capacity, driver, status):
        vehicle = self.db.fetch_one("SELECT current_shipment_id FROM vehicles WHERE id=%s", (vehicle_id,))
        if vehicle and vehicle["current_shipment_id"] and status == "Sẵn sàng":
            raise ValueError("Xe đang phụ trách lô hàng, hãy giải phóng qua lô hàng hoặc nút Giải phóng xe.")
        self.db.execute(
            "UPDATE vehicles SET plate=%s, vehicle_type=%s, capacity=%s, driver=%s, status=%s WHERE id=%s",
            (plate, vehicle_type, capacity, driver, status, vehicle_id),
        ).close()
        self.db.commit()

    def release_vehicle(self, vehicle_id):
        self.db.execute("UPDATE vehicles SET status='Sẵn sàng', current_shipment_id=NULL WHERE id=%s", (vehicle_id,)).close()
        self.db.execute("UPDATE shipments SET vehicle_id=NULL WHERE vehicle_id=%s AND status <> 'Đã giao'", (vehicle_id,)).close()
        self.db.commit()

    def next_container_code(self):
        return next_code(self.db, "containers", "CONT")

    def next_vehicle_code(self):
        return next_code(self.db, "vehicles", "VH")
