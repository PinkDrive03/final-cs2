from utils.helpers import next_code


class OrderService:
    VALID_PROCESS_STATUSES = ("Chờ xử lý", "Đang xử lý")

    def __init__(self, db, inventory_service):
        self.db = db
        self.inventory_service = inventory_service

    def customers_for_choice(self):
        return self.db.fetch_all("SELECT id, code, name, address FROM customers ORDER BY name")

    def list_orders(self, filters=None):
        filters = filters or {}
        sql = """
            SELECT o.id, o.code, c.name AS customer_name, o.order_date,
                   p.sku, p.name AS product_name, oi.quantity,
                   o.delivery_address, o.priority, o.status
            FROM orders o
            JOIN customers c ON c.id=o.customer_id
            JOIN order_items oi ON oi.order_id=o.id
            JOIN products p ON p.id=oi.product_id
            WHERE 1=1
        """
        params = []
        if filters.get("keyword"):
            code_sql, code_params = self._code_search_clause(filters["keyword"])
            sql += f" AND ({code_sql} OR c.name LIKE %s OR o.status LIKE %s)"
            kw = f"%{filters['keyword']}%"
            params += code_params + [kw, kw]
        if filters.get("code"):
            code_sql, code_params = self._code_search_clause(filters["code"])
            sql += f" AND ({code_sql})"
            params += code_params
        if filters.get("customer"):
            sql += " AND c.name LIKE %s"
            params.append(f"%{filters['customer']}%")
        if filters.get("status"):
            sql += " AND o.status=%s"
            params.append(filters["status"])
        sql += " ORDER BY o.order_date DESC, o.id DESC"
        return self.db.fetch_all(sql, tuple(params))

    def _code_search_clause(self, value):
        text = str(value).strip()
        variants = [text]
        digits = "".join(ch for ch in text if ch.isdigit())
        if digits:
            variants.extend([digits, digits.zfill(4), digits.lstrip("0") or "0"])
        seen = []
        for variant in variants:
            if variant and variant not in seen:
                seen.append(variant)
        clause = " OR ".join(["o.code LIKE %s"] * len(seen))
        return clause, [f"%{variant}%" for variant in seen]

    def get_order(self, order_id):
        return self.db.fetch_one(
            """
            SELECT o.*, c.name AS customer_name, p.id AS product_id, p.sku,
                   p.name AS product_name, oi.quantity
            FROM orders o
            JOIN customers c ON c.id=o.customer_id
            JOIN order_items oi ON oi.order_id=o.id
            JOIN products p ON p.id=oi.product_id
            WHERE o.id=%s
            """,
            (order_id,),
        )

    def create_order(self, code, customer_id, order_date, product_id, quantity, delivery_address, priority):
        if self.db.fetch_one("SELECT id FROM orders WHERE code=%s", (code,)):
            raise ValueError("Mã đơn hàng đã tồn tại.")
        order_id = self.db.insert(
            """
            INSERT INTO orders (code, customer_id, order_date, delivery_address, priority, status)
            VALUES (%s,%s,%s,%s,%s,'Chờ xử lý')
            """,
            (code, customer_id, order_date, delivery_address, priority),
        )
        self.db.insert(
            "INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s,%s,%s)",
            (order_id, product_id, quantity),
        )
        self.db.commit()
        return order_id

    def update_order(self, order_id, customer_id, order_date, product_id, quantity, delivery_address, priority, status):
        shipment = self.db.fetch_one("SELECT id FROM shipments WHERE order_id=%s", (order_id,))
        if shipment and status == "Đã hủy":
            raise ValueError("Không thể hủy đơn đã có lô hàng.")
        self.db.execute(
            """
            UPDATE orders SET customer_id=%s, order_date=%s, delivery_address=%s,
            priority=%s, status=%s WHERE id=%s
            """,
            (customer_id, order_date, delivery_address, priority, status, order_id),
        ).close()
        item = self.db.fetch_one("SELECT id FROM order_items WHERE order_id=%s", (order_id,))
        self.db.execute(
            "UPDATE order_items SET product_id=%s, quantity=%s WHERE id=%s",
            (product_id, quantity, item["id"]),
        ).close()
        self.db.commit()

    def delete_order(self, order_id):
        if self.db.fetch_one("SELECT id FROM shipments WHERE order_id=%s", (order_id,)):
            raise ValueError("Không thể xóa đơn đã tạo lô hàng.")
        self.db.execute("DELETE FROM orders WHERE id=%s", (order_id,)).close()
        self.db.commit()

    def process_order(self, order_id):
        order = self.get_order(order_id)
        if not order:
            raise ValueError("Không tìm thấy đơn hàng.")
        if order["status"] not in self.VALID_PROCESS_STATUSES:
            raise ValueError("Chỉ xử lý đơn ở trạng thái Chờ xử lý hoặc Đang xử lý.")
        available = self.inventory_service.total_stock(order["product_id"])
        if available < order["quantity"]:
            raise ValueError(f"Không đủ tồn kho. Yêu cầu {order['quantity']}, hiện có {available}.")
        try:
            self.inventory_service.deduct_product_stock(order["product_id"], order["quantity"])
            self.db.execute("UPDATE orders SET status='Sẵn sàng giao' WHERE id=%s", (order_id,)).close()
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def next_order_code(self):
        return next_code(self.db, "orders", "ORD")

