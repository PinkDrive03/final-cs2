"""Build crisp, UI-sized mascot assets from transparent master images.

This is a development utility only. The Tkinter application loads the generated
PNG files directly and does not require Pillow at runtime.
"""

from pathlib import Path

from PIL import Image, ImageFilter


PROJECT_ROOT = Path(__file__).resolve().parent.parent
ASSET_DIR = PROJECT_ROOT / "assets"

ASSETS = {
    "mascot_welcome_cutout.png": ("mascot_welcome_ui.png", 230),
    "mascot_orders_cutout.png": ("mascot_orders_ui.png", 140),
    "mascot_stock_cutout.png": ("mascot_stock_ui.png", 140),
    "mascot_reports_cutout.png": ("mascot_reports_ui.png", 140),
}


def build_ui_asset(source_name, output_name, canvas_size):
    source = Image.open(ASSET_DIR / source_name).convert("RGBA")
    source.thumbnail((canvas_size, canvas_size), Image.Resampling.LANCZOS)

    red, green, blue, alpha = source.split()
    rgb = Image.merge("RGB", (red, green, blue)).filter(
        ImageFilter.UnsharpMask(radius=0.7, percent=115, threshold=2)
    )
    red, green, blue = rgb.split()
    alpha = alpha.point(lambda value: 0 if value < 36 else value)
    source = Image.merge("RGBA", (red, green, blue, alpha))

    canvas = Image.new("RGBA", (canvas_size, canvas_size), (0, 0, 0, 0))
    left = (canvas_size - source.width) // 2
    top = (canvas_size - source.height) // 2
    canvas.alpha_composite(source, (left, top))
    canvas.save(ASSET_DIR / output_name, optimize=True)


def main():
    for source_name, (output_name, canvas_size) in ASSETS.items():
        build_ui_asset(source_name, output_name, canvas_size)
        print(f"Created {output_name} ({canvas_size}x{canvas_size})")


if __name__ == "__main__":
    main()
