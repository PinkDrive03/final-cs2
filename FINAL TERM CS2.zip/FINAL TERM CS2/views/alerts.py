from views.base_page import BasePage, TableMixin


class AlertPage(BasePage, TableMixin):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Hệ thống cảnh báo")
        self.build_filter_bar(self, [("Trạng thái", "status", ["", "Đang mở", "Đã xử lý"])])
        self.build_action_bar(self, [("Đánh dấu đã xử lý", self.resolve_alert), ("Làm mới", self.refresh)])
        columns = ("code", "type", "related", "content", "severity", "created", "status")
        headings = ("Mã cảnh báo", "Loại", "Đối tượng", "Nội dung", "Mức độ", "Ngày tạo", "Trạng thái")
        self.build_table(self, columns, headings, {"content": 320})

    def refresh(self):
        self.app.alert_service.check_late_shipments()
        self.app.alert_service.check_container_eta()
        self.db.commit()
        self.clear_table()
        status = self.filter_vars["status"].get() or None
        for row in self.app.alert_service.list_alerts(status=status):
            self.tree.insert("", "end", iid=row["id"], values=(
                row["code"], row["type"], f"{row['related_table']} #{row['related_id']}",
                row["content"], row["severity"], row["created_at"], row["status"]
            ))

    def resolve_alert(self):
        if not self.selected_required():
            return
        try:
            self.app.alert_service.mark_resolved(self.selected_id)
            self.notify_success("Cảnh báo đã được đánh dấu Đã xử lý.")
        except Exception as exc:
            self.notify_error(exc)

