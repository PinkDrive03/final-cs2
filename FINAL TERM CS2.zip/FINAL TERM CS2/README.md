# LOGTECH WMS - HỆ THỐNG QUẢN LÝ KHO

Ứng dụng desktop 100% Python dùng Tkinter/ttk, MySQL và `mysql-connector-python`.
Giao diện không sử dụng HTML, CSS hay JavaScript.
Toàn bộ chức năng nghiệp vụ nằm trong service class, giao diện nằm trong các page class kế thừa `BasePage`.

## 1. Cài đặt MySQL

1. Cài MySQL Server 8.x hoặc MariaDB tương thích.
2. Bật dịch vụ MySQL.
3. Tạo user có quyền tạo database, hoặc dùng user `root`.
4. Cập nhật thông tin kết nối trong `config.py`:

```python
DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = "mat_khau_mysql"
DB_NAME = "logiflow_db"
DB_PORT = 3306
```

Cũng có thể dùng biến môi trường:

```powershell
$env:LOGTECH_DB_PASSWORD="mat_khau_mysql"
```

## 2. Cài dependency

```powershell
python -m pip install -r requirements.txt
```

## 3. Tạo database và dữ liệu demo

Chương trình tự tạo database `logiflow_db`, schema và dữ liệu demo khi chạy lần đầu.
Có thể seed thủ công:

```powershell
python data\seed_data.py
```

Dữ liệu demo gồm khoảng 20 khách hàng, 30 sản phẩm, 3 kho, nhiều vị trí, 40 đơn hàng, 15 lô hàng, 10 container, 10 phương tiện và cảnh báo.

## 4. Chạy ứng dụng

```powershell
python main.py
```

Ứng dụng chỉ tạo một cửa sổ `Tk()` chính, sidebar bên trái và nội dung bên phải.
Mascot được đặt trong thư mục `assets/` và hiển thị bằng `tk.PhotoImage`.

## 5. Các màn hình chính

Ứng dụng được rút gọn theo phạm vi WMS cơ bản để dễ dùng và dễ demo.

1. Tổng quan: KPI cốt lõi, đơn hàng gần đây, SKU sắp hết và lối tắt thao tác.
2. Đơn hàng: thêm, xem chi tiết bằng nhấp đúp, sửa, xóa và xử lý đơn.
3. Tồn kho & kho: quản lý SKU, nhập/xuất hàng, kho và vị trí lưu trữ.
4. Báo cáo: tồn kho, đơn hàng, đề xuất nhập hàng và xuất CSV.

Các màn vận chuyển, container, phương tiện và cảnh báo riêng đã được bỏ khỏi điều hướng.
Cảnh báo tồn kho quan trọng được đưa thẳng lên dashboard; bảng dữ liệu cũ vẫn được giữ để tương thích database.

## 6. Sơ đồ database và quan hệ

- `customers` -> `orders`
- `orders` -> `order_items` -> `products`
- `products` -> `inventory` -> `warehouse_locations` -> `warehouses`
- `orders` -> `shipments`
- `shipments` -> `containers`
- `shipments` -> `vehicles`
- `alerts` liên kết mềm bằng `related_table`, `related_id`, `issue_key`

Các bảng chính dùng `PRIMARY KEY`, `UNIQUE`, `FOREIGN KEY`, `NOT NULL` và `CHECK` tại các cột phù hợp.

## 7. OOP được dùng ở đâu

- Encapsulation: `DatabaseManager` đóng gói kết nối, query, commit, rollback và tạo schema.
- Inheritance: mọi màn hình kế thừa `BasePage`; các trang bảng dùng thêm `TableMixin`.
- Abstraction: `OrderService`, `InventoryService`, `ShipmentService`, `TransportService`, `AlertService` che chi tiết SQL khỏi GUI.
- Composition: `LogTechApp` sở hữu các service; service gọi nhau để xử lý luồng thật như đơn hàng -> tồn kho -> cảnh báo -> shipment -> xe/container.
- Models: `models/entities.py` có các dataclass `Product`, `Order`, `Shipment`, `Warehouse`, `Container`, `Vehicle`, `Alert`.

## 8. File nào làm gì

- `main.py`: điểm bắt đầu, tạo app, theme, sidebar và 4 khu vực WMS chính.
- `config.py`: cấu hình MySQL và thư mục báo cáo.
- `database/database_manager.py`: kết nối MySQL, tạo database/schema, execute/fetch/commit/rollback.
- `models/entities.py`: các class dữ liệu cốt lõi.
- `services/order_service.py`: tạo/sửa/xóa/xử lý đơn hàng, kiểm tra tồn kho.
- `services/inventory_service.py`: tồn kho, nhập/xuất, trạng thái tồn, cảnh báo tồn thấp.
- `services/shipment_service.py`: nghiệp vụ logistics cũ, hiện không hiển thị trong giao diện WMS cơ bản.
- `services/transport_service.py`: nghiệp vụ vận tải cũ, hiện không hiển thị trong giao diện WMS cơ bản.
- `services/alert_service.py`: tạo cảnh báo không trùng, kiểm tra trễ/ETA, xử lý cảnh báo.
- `views/*.py`: giao diện Tkinter tiếng Việt, các màn liên quan được gom lại để dễ dùng.
- `data/seed_data.py`: tạo dữ liệu demo.
- `reports/`: nơi lưu file CSV xuất ra.

## 9. Kịch bản demo 10 phút

1. Mở Dashboard, xem KPI lấy từ MySQL.
2. Vào Tồn kho, tìm `SKU001` hoặc `Laptop`: tồn ban đầu 50, mức tối thiểu 25.
3. Vào Đơn hàng, thêm đơn cho `ABC Store`, sản phẩm `SKU001 - Laptop`, số lượng 30.
4. Chọn đơn vừa tạo, bấm `Xử lý đơn hàng`.
5. Quay lại Tồn kho: Laptop còn 20.
6. Vào Cảnh báo: có cảnh báo sản phẩm xuống dưới mức tồn tối thiểu.
7. Vào Lô hàng, tạo lô từ đơn vừa xử lý.
8. Gán một container và một xe đang `Sẵn sàng`.
9. Cập nhật lô hàng `Sẵn sàng` -> `Đang vận chuyển`, Dashboard cập nhật lô đang vận chuyển.
10. Cập nhật lô hàng `Đã giao`, kiểm tra đơn thành `Đã giao` và xe quay lại `Sẵn sàng`.

## 10. Lưu ý validation

Ứng dụng kiểm tra field bắt buộc, số lượng nguyên dương, mức tồn không âm, ngày dạng `YYYY-MM-DD`, không xuất âm kho, không xử lý đơn thiếu tồn kho, không gán xe đang bận và không tạo cảnh báo trùng cho cùng một vấn đề.

## 11. Hạn chế còn lại

- Chưa có phân quyền/login vì yêu cầu không thêm login phức tạp.
- Chưa có bản đồ kho, GPS, route optimization, API online hoặc cloud database.
- Mỗi đơn hàng trong GUI demo dùng một dòng sản phẩm để giữ phạm vi vừa đủ cho thuyết trình.
- Cần cấu hình đúng user/password MySQL cục bộ trước khi chạy seed và app.
