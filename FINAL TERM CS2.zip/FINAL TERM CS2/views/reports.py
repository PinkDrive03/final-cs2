import csv
import os
import unicodedata
from datetime import date
from tkinter import messagebox, ttk

import config
from views.base_page import BasePage


class ReportPage(BasePage):
    REPORTS = ("Báo cáo tồn kho", "Báo cáo đơn hàng", "Đề xuất nhập hàng")

    def __init__(self, parent, app):
        super().__init__(
            parent,
            app,
            "Báo cáo",
            mascot="mascot_reports_ui.png",
            mascot_tip="Cần đối soát thì chọn báo cáo\nvà xuất CSV ở đây.",
        )
        top = ttk.Frame(self, style="Toolbar.TFrame", padding=(14, 11))
        top.pack(fill="x", pady=(0, 10))
        ttk.Label(top, text="Loại báo cáo", style="Toolbar.TLabel").pack(side="left", padx=(0, 8))
        self.report_var = ttk.Combobox(top, values=self.REPORTS, state="readonly", width=28)
        self.report_var.set(self.REPORTS[0])
        self.report_var.pack(side="left", padx=(0, 8))
        self.report_var.bind("<<ComboboxSelected>>", lambda _event: self.refresh())
        ttk.Button(top, text="Xem báo cáo", style="Primary.TButton", command=self.refresh).pack(side="left", padx=4)
        ttk.Button(top, text="Xuất CSV", style="Secondary.TButton", command=self.export_csv).pack(side="left", padx=4)

        self.stats = ttk.Frame(self, style="Card.TFrame", padding=(16, 12))
        self.stats.pack(fill="x", pady=(0, 10))
        ttk.Label(self.stats, text="Tóm tắt", style="SectionTitle.TLabel").pack(anchor="w", pady=(0, 8))
        self.stats_values = ttk.Frame(self.stats, style="Card.TFrame")
        self.stats_values.pack(fill="x")

        table = ttk.Frame(self, style="Card.TFrame", padding=1)
        table.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table, show="headings")
        vertical = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        horizontal = ttk.Scrollbar(table, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")
        table.rowconfigure(0, weight=1)
        table.columnconfigure(0, weight=1)
        self.tree.tag_configure("odd", background="#fffaf2")
        self.tree.tag_configure("even", background="#ffffff")

    def refresh(self):
        _title, headings, rows, stats = self._report_data()
        for child in self.stats_values.winfo_children():
            child.destroy()
        for index, (label, value) in enumerate(stats):
            box = ttk.Frame(self.stats_values, style="WarmCard.TFrame", padding=(13, 8))
            box.grid(row=0, column=index, sticky="ew", padx=(0 if index == 0 else 5, 0 if index == len(stats) - 1 else 5))
            ttk.Label(box, text=label, style="KpiAccent.TLabel").pack(anchor="w")
            ttk.Label(box, text=str(value), style="WarmValue.TLabel").pack(anchor="w")
            self.stats_values.columnconfigure(index, weight=1)

        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = headings
        for heading in headings:
            self.tree.heading(heading, text=heading)
            self.tree.column(heading, width=155, anchor="w")
        for index, row in enumerate(rows):
            self.tree.insert("", "end", values=row, tags=("even" if index % 2 == 0 else "odd",))

    def export_csv(self):
        title, headings, rows, _stats = self._report_data()
        os.makedirs(config.REPORT_DIR, exist_ok=True)
        safe = unicodedata.normalize("NFKD", title.lower()).encode("ascii", "ignore").decode("ascii")
        safe = safe.replace(" ", "_").replace("&", "va")
        path = os.path.join(config.REPORT_DIR, f"{safe}_{date.today().isoformat()}.csv")
        with open(path, "w", newline="", encoding="utf-8-sig") as file:
            writer = csv.writer(file)
            writer.writerow(headings)
            writer.writerows(rows)
        messagebox.showinfo("Đã xuất báo cáo", f"Tệp CSV được lưu tại:\n{path}")

    def _report_data(self):
        name = self.report_var.get()
        if name == "Báo cáo tồn kho":
            rows_raw = self.app.inventory_service.list_inventory()
            rows = [
                (
                    row["sku"],
                    row["product_name"],
                    row["warehouse_code"],
                    row["location_code"],
                    row["quantity"],
                    row["min_stock"],
                    row["stock_status"],
                )
                for row in rows_raw
            ]
            stats = (
                ("Tổng SKU", len({row["sku"] for row in rows_raw})),
                ("Tổng số lượng", sum(row["quantity"] for row in rows_raw)),
                ("Sắp hết", sum(1 for row in rows_raw if row["stock_status"] == "Sắp hết hàng")),
                ("Hết hàng", sum(1 for row in rows_raw if row["stock_status"] == "Hết hàng")),
            )
            return name, ("SKU", "Sản phẩm", "Kho", "Vị trí", "Số lượng", "Tối thiểu", "Trạng thái"), rows, stats

        if name == "Báo cáo đơn hàng":
            rows_raw = self.app.order_service.list_orders()
            rows = [
                (row["code"], row["customer_name"], row["order_date"], row["product_name"], row["quantity"], row["status"])
                for row in rows_raw
            ]
            stats = (
                ("Tổng đơn", len(rows)),
                ("Chờ xử lý", sum(1 for row in rows_raw if row["status"] == "Chờ xử lý")),
                ("Sẵn sàng giao", sum(1 for row in rows_raw if row["status"] == "Sẵn sàng giao")),
                ("Đã giao", sum(1 for row in rows_raw if row["status"] == "Đã giao")),
            )
            return name, ("Mã đơn", "Khách hàng", "Ngày", "Sản phẩm", "Số lượng", "Trạng thái"), rows, stats

        rows_raw = self.db.fetch_all(
            """
            SELECT p.sku, p.name, COALESCE(SUM(i.quantity),0) AS quantity, p.min_stock
            FROM products p
            LEFT JOIN inventory i ON i.product_id=p.id
            GROUP BY p.id, p.sku, p.name, p.min_stock
            HAVING quantity <= p.min_stock
            ORDER BY quantity ASC, p.sku
            """
        )
        rows = [
            (
                row["sku"],
                row["name"],
                row["quantity"],
                row["min_stock"],
                max(int(row["min_stock"]) - int(row["quantity"]), 0),
                "Hết hàng" if int(row["quantity"]) == 0 else "Sắp hết hàng",
            )
            for row in rows_raw
        ]
        stats = (
            ("SKU cần nhập", len(rows)),
            ("Đã hết hàng", sum(1 for row in rows_raw if int(row["quantity"]) == 0)),
            ("Sắp hết", sum(1 for row in rows_raw if int(row["quantity"]) > 0)),
            ("SL đề xuất", sum(max(int(row["min_stock"]) - int(row["quantity"]), 0) for row in rows_raw)),
        )
        return name, ("SKU", "Sản phẩm", "Hiện có", "Tối thiểu", "Cần bổ sung", "Trạng thái"), rows, stats
