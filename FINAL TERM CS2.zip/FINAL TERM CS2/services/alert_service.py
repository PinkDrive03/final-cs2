from datetime import datetime, date

from utils.helpers import next_code


class AlertService:
    def __init__(self, db):
        self.db = db

    def create_unique(self, alert_type, related_table, related_id, issue_key, content, severity):
        existing = self.db.fetch_one("SELECT id, status FROM alerts WHERE issue_key=%s", (issue_key,))
        if existing:
            if existing["status"] == "Đã xử lý":
                self.db.execute(
                    "UPDATE alerts SET status='Đang mở', created_at=%s, content=%s, severity=%s WHERE id=%s",
                    (datetime.now(), content, severity, existing["id"]),
                ).close()
            return existing["id"]
        code = next_code(self.db, "alerts", "AL")
        return self.db.insert(
            """
            INSERT INTO alerts
            (code, type, related_table, related_id, issue_key, content, severity, created_at, status)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'Đang mở')
            """,
            (code, alert_type, related_table, related_id, issue_key, content, severity, datetime.now()),
        )

    def resolve_issue(self, issue_key):
        cursor = self.db.execute("UPDATE alerts SET status='Đã xử lý' WHERE issue_key=%s", (issue_key,))
        cursor.close()

    def mark_resolved(self, alert_id):
        cursor = self.db.execute("UPDATE alerts SET status='Đã xử lý' WHERE id=%s", (alert_id,))
        cursor.close()
        self.db.commit()

    def list_alerts(self, status=None, limit=None):
        sql = "SELECT * FROM alerts"
        params = []
        if status:
            sql += " WHERE status=%s"
            params.append(status)
        sql += " ORDER BY created_at DESC"
        if limit:
            sql += " LIMIT %s"
            params.append(limit)
        return self.db.fetch_all(sql, tuple(params))

    def check_late_shipments(self):
        rows = self.db.fetch_all(
            """
            SELECT id, code, expected_arrival FROM shipments
            WHERE expected_arrival < %s AND status NOT IN ('Đã giao','Đã hủy','Trễ')
            """,
            (date.today(),),
        )
        for row in rows:
            self.db.execute("UPDATE shipments SET status='Trễ' WHERE id=%s", (row["id"],)).close()
            self.create_unique(
                "Lô hàng giao trễ",
                "shipments",
                row["id"],
                f"shipment_late:{row['id']}",
                f"Lô hàng {row['code']} đã quá ngày dự kiến đến.",
                "Nghiêm trọng",
            )

    def check_container_eta(self):
        rows = self.db.fetch_all(
            """
            SELECT id, code, eta FROM containers
            WHERE eta < %s AND status NOT IN ('Đã đến','Đã dỡ hàng')
            """,
            (date.today(),),
        )
        for row in rows:
            self.create_unique(
                "Container quá ETA",
                "containers",
                row["id"],
                f"container_eta:{row['id']}",
                f"Container {row['code']} đã quá ETA nhưng chưa đến.",
                "Cảnh báo",
            )

