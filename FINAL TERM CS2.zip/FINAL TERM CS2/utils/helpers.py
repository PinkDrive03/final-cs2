from datetime import date


def today_str():
    return date.today().isoformat()


def inventory_status(quantity, min_stock):
    if quantity == 0:
        return "Het hang"
    if quantity <= min_stock:
        return "Sap het hang"
    return "Binh thuong"


def next_code(db, table, prefix):
    row = db.fetch_one(f"SELECT COUNT(*) AS total FROM {table}")
    return f"{prefix}{(row['total'] or 0) + 1:04d}"


def parse_location_code(code):
    parts = (code or "").split("-")
    if len(parts) != 3:
        return "", "", ""
    return parts[0], parts[1], parts[2]
