from datetime import datetime


def require_fields(values, labels):
    for value, label in zip(values, labels):
        if value is None or str(value).strip() == "":
            raise ValueError(f"Vui long nhap {label}.")


def positive_int(value, label="So luong"):
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} phai la so nguyen hop le.") from exc
    if number <= 0:
        raise ValueError(f"{label} phai lon hon 0.")
    return number


def non_negative_int(value, label="Gia tri"):
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} phai la so nguyen hop le.") from exc
    if number < 0:
        raise ValueError(f"{label} khong duoc am.")
    return number


def decimal_number(value, label="Gia tri"):
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} phai la so hop le.") from exc
    if number < 0:
        raise ValueError(f"{label} khong duoc am.")
    return number


def valid_date(value, label="Ngay"):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} phai dung dinh dang YYYY-MM-DD.") from exc
