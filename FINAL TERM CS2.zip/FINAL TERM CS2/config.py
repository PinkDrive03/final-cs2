import os


BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DB_HOST = os.getenv("LOGTECH_DB_HOST", os.getenv("LOGIFLOW_DB_HOST", "localhost"))
DB_USER = os.getenv("LOGTECH_DB_USER", os.getenv("LOGIFLOW_DB_USER", "root"))
DB_PASSWORD = os.getenv("LOGTECH_DB_PASSWORD", os.getenv("LOGIFLOW_DB_PASSWORD", "MySQL"))
DB_NAME = os.getenv("LOGTECH_DB_NAME", os.getenv("LOGIFLOW_DB_NAME", "logiflow_db"))
DB_PORT = int(os.getenv("LOGTECH_DB_PORT", os.getenv("LOGIFLOW_DB_PORT", "3306")))

APP_TITLE = "LOGTECH WMS - Quản lý kho"
ASSET_DIR = os.path.join(BASE_DIR, "assets")
REPORT_DIR = os.path.join(BASE_DIR, "reports")
