from utils.validators import require_fields, valid_date
from views.base_page import BasePage, TableMixin, FormDialog, choice_label, id_from_choice


SHIPMENT_STATUSES = ["Chờ xử lý", "Sẵn sàng", "Đang vận chuyển", "Đã giao", "Trễ", "Đã hủy"]


class ShipmentPage(BasePage, TableMixin):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Quản lý lô hàng")
        self.build_filter_bar(self, [
            ("Mã lô", "code", None),
            ("Mã đơn", "order_code", None),
            ("Điểm đến", "destination", None),
            ("Trạng thái", "status", [""] + SHIPMENT_STATUSES),
        ])
        self.build_action_bar(self, [
            ("Tạo lô từ đơn", self.create_shipment),
            ("Chỉnh sửa", self.edit_shipment),
            ("Gán container", self.assign_container),
            ("Gán phương tiện", self.assign_vehicle),
            ("Cập nhật trạng thái", self.update_status),
        ])
        columns = ("code", "order", "origin", "dest", "depart", "expected", "actual", "container", "vehicle", "status")
        headings = ("Mã lô", "Mã đơn", "Điểm đi", "Điểm đến", "Khởi hành", "Dự kiến đến", "Thực tế đến", "Container", "Phương tiện", "Trạng thái")
        self.build_table(self, columns, headings, {"origin": 150, "dest": 180})

    def refresh(self):
        self.app.alert_service.check_late_shipments()
        self.db.commit()
        filters = {k: v.get() for k, v in self.filter_vars.items() if v.get()}
        self.clear_table()
        for row in self.app.shipment_service.list_shipments(filters):
            self.tree.insert("", "end", iid=row["id"], values=(
                row["code"], row["order_code"], row["origin"], row["destination"], row["departure_date"],
                row["expected_arrival"], row["actual_arrival"] or "", row["container_code"] or "",
                row["vehicle_plate"] or "", row["status"]
            ))

    def create_shipment(self):
        orders = [choice_label(r, "id", "code", "customer_name") for r in self.app.shipment_service.orders_ready_for_shipment()]
        dialog = FormDialog(self, "Tạo lô hàng từ đơn", [
            ("Mã lô hàng", "code"),
            ("Đơn hàng", "order", orders),
            ("Điểm đi", "origin"),
            ("Điểm đến", "destination"),
            ("Ngày khởi hành (YYYY-MM-DD)", "departure_date"),
            ("Ngày dự kiến đến (YYYY-MM-DD)", "expected_arrival"),
        ], {"code": self.app.shipment_service.next_shipment_code(), "origin": "Kho TP.HCM"})
        if not dialog.result:
            return
        try:
            data = dialog.result
            require_fields(data.values(), ["mã lô", "đơn hàng", "điểm đi", "điểm đến", "ngày khởi hành", "ngày dự kiến"])
            self.app.shipment_service.create_from_order(
                data["code"], id_from_choice(data["order"]), data["origin"], data["destination"],
                valid_date(data["departure_date"], "Ngày khởi hành"),
                valid_date(data["expected_arrival"], "Ngày dự kiến đến")
            )
            self.notify_success("Lô hàng đã được tạo.")
        except Exception as exc:
            self.notify_error(exc)

    def edit_shipment(self):
        if not self.selected_required():
            return
        row = self.db.fetch_one("SELECT * FROM shipments WHERE id=%s", (self.selected_id,))
        dialog = FormDialog(self, "Chỉnh sửa lô hàng", [
            ("Điểm đi", "origin"),
            ("Điểm đến", "destination"),
            ("Ngày khởi hành (YYYY-MM-DD)", "departure_date"),
            ("Ngày dự kiến đến (YYYY-MM-DD)", "expected_arrival"),
            ("Ngày thực tế đến (YYYY-MM-DD)", "actual_arrival"),
            ("Trạng thái", "status", SHIPMENT_STATUSES),
        ], row)
        if not dialog.result:
            return
        try:
            data = dialog.result
            self.app.shipment_service.update_shipment(
                self.selected_id, data["origin"], data["destination"],
                valid_date(data["departure_date"], "Ngày khởi hành"),
                valid_date(data["expected_arrival"], "Ngày dự kiến đến"),
                valid_date(data["actual_arrival"], "Ngày thực tế đến") if data["actual_arrival"] else None,
                data["status"]
            )
            self.notify_success("Lô hàng đã được cập nhật.")
        except Exception as exc:
            self.notify_error(exc)

    def assign_container(self):
        if not self.selected_required():
            return
        containers = [choice_label(r, "id", "code", "type") for r in self.app.shipment_service.available_containers()]
        dialog = FormDialog(self, "Gán container", [("Container", "container", containers)])
        if not dialog.result:
            return
        try:
            self.app.shipment_service.assign_container(self.selected_id, id_from_choice(dialog.result["container"]))
            self.notify_success("Container đã được gán vào lô hàng.")
        except Exception as exc:
            self.notify_error(exc)

    def assign_vehicle(self):
        if not self.selected_required():
            return
        vehicles = [choice_label(r, "id", "plate", "driver") for r in self.app.shipment_service.available_vehicles()]
        dialog = FormDialog(self, "Gán phương tiện", [("Phương tiện sẵn sàng", "vehicle", vehicles)])
        if not dialog.result:
            return
        try:
            self.app.shipment_service.assign_vehicle(self.selected_id, id_from_choice(dialog.result["vehicle"]))
            self.notify_success("Phương tiện đã được gán vào lô hàng.")
        except Exception as exc:
            self.notify_error(exc)

    def update_status(self):
        if not self.selected_required():
            return
        dialog = FormDialog(self, "Cập nhật trạng thái lô hàng", [("Trạng thái", "status", SHIPMENT_STATUSES)])
        if not dialog.result:
            return
        try:
            self.app.shipment_service.update_status(self.selected_id, dialog.result["status"])
            self.notify_success("Trạng thái lô hàng đã được cập nhật.")
        except Exception as exc:
            self.notify_error(exc)

