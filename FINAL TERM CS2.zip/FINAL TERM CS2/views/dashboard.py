import tkinter as tk
from tkinter import ttk

from views.base_page import BasePage


class DashboardPage(BasePage):
    KPI_DEFINITIONS = (
        ("Sản phẩm", "Tổng SKU đang quản lý", "#ff9f0a"),
        ("Tồn kho", "Tổng đơn vị trong kho", "#2f9d68"),
        ("Đơn cần xử lý", "Chờ xử lý hoặc đang xử lý", "#4b7bec"),
        ("Cảnh báo tồn", "Sản phẩm cần chú ý", "#df5b4f"),
    )

    def __init__(self, parent, app):
        super().__init__(
            parent,
            app,
            "Tổng quan kho hàng",
        )
        self._build_hero()
        self._build_kpis()
        self._build_operations()

    def _build_hero(self):
        hero = ttk.Frame(self, style="Hero.TFrame", padding=(24, 18))
        hero.pack(fill="x", pady=(0, 14))

        copy = ttk.Frame(hero, style="Hero.TFrame")
        copy.pack(side="left", fill="both", expand=True)
        ttk.Label(copy, text="CÔNG VIỆC HÔM NAY", style="HeroEyebrow.TLabel").pack(anchor="w")
        ttk.Label(copy, text="Kiểm tra kho\nmột vòng nhé!", style="HeroTitle.TLabel").pack(anchor="w", pady=(12, 6))
        ttk.Label(
            copy,
            text="Xem tồn kho, xử lý đơn đang chờ và bổ sung\nnhững mặt hàng sắp hết.",
            style="HeroBody.TLabel",
            justify="left",
        ).pack(anchor="w")
        actions = ttk.Frame(copy, style="Hero.TFrame")
        actions.pack(anchor="w", pady=(14, 0))
        ttk.Button(
            actions,
            text="Kiểm tra tồn kho  →",
            style="Primary.TButton",
            command=lambda: self.app.show_page("Tồn kho & kho"),
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            actions,
            text="Xử lý đơn hàng",
            style="Secondary.TButton",
            command=lambda: self.app.show_page("Đơn hàng"),
        ).pack(side="left")

        guide = ttk.Frame(hero, style="Hero.TFrame")
        guide.pack(side="right", padx=(18, 0))
        self.mascot_tip = ttk.Label(
            guide,
            text="Mình kiểm tra hàng sắp hết trước nhé!",
            style="HeroTip.TLabel",
            justify="left",
        )
        self.mascot_tip.pack(anchor="e", pady=(0, 4))
        self.mascot = self.app.load_image("mascot_welcome_ui.png", max_width=230, max_height=230)
        if self.mascot:
            tk.Label(guide, image=self.mascot, bg="#ffffff", borderwidth=0).pack(anchor="e")

    def _build_kpis(self):
        self.kpi_frame = ttk.Frame(self, style="Content.TFrame")
        self.kpi_frame.pack(fill="x", pady=(0, 14))
        self.kpi_labels = {}
        for index, (title, helper, color) in enumerate(self.KPI_DEFINITIONS):
            box = ttk.Frame(self.kpi_frame, style="Card.TFrame")
            box.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 5, 0 if index == 3 else 5))
            tk.Frame(box, height=4, bg=color).pack(fill="x")
            body = ttk.Frame(box, style="Card.TFrame", padding=(15, 11))
            body.pack(fill="both", expand=True)
            ttk.Label(body, text=title, style="Small.TLabel").pack(anchor="w")
            value = ttk.Label(body, text="0", style="Kpi.TLabel")
            value.pack(anchor="w", pady=(2, 0))
            ttk.Label(body, text=helper, style="Muted.TLabel").pack(anchor="w")
            self.kpi_labels[title] = value
            self.kpi_frame.columnconfigure(index, weight=1)

    def _build_operations(self):
        area = ttk.Frame(self, style="Content.TFrame")
        area.pack(fill="both", expand=True)
        area.columnconfigure(0, weight=3)
        area.columnconfigure(1, weight=2)
        area.rowconfigure(0, weight=1)

        orders = ttk.Frame(area, style="Card.TFrame", padding=(16, 12))
        orders.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        ttk.Label(orders, text="Đơn hàng gần đây", style="SectionTitle.TLabel").pack(anchor="w")
        self.order_tree = ttk.Treeview(
            orders,
            columns=("code", "customer", "quantity", "status"),
            show="headings",
            height=5,
        )
        for column, title, width in (
            ("code", "Mã đơn", 100),
            ("customer", "Khách hàng", 165),
            ("quantity", "SL", 55),
            ("status", "Trạng thái", 120),
        ):
            self.order_tree.heading(column, text=title)
            self.order_tree.column(column, width=width, anchor="w")
        self.order_tree.pack(fill="both", expand=True, pady=(8, 0))

        alerts = ttk.Frame(area, style="Card.TFrame", padding=(16, 12))
        alerts.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        ttk.Label(alerts, text="Ưu tiên bổ sung hàng", style="SectionTitle.TLabel").pack(anchor="w")
        self.low_stock_frame = ttk.Frame(alerts, style="Card.TFrame")
        self.low_stock_frame.pack(fill="both", expand=True, pady=(8, 0))

    def refresh(self):
        values = {
            "Sản phẩm": self.db.fetch_one("SELECT COUNT(*) total FROM products")["total"],
            "Tồn kho": self.db.fetch_one("SELECT COALESCE(SUM(quantity),0) total FROM inventory")["total"],
            "Đơn cần xử lý": self.db.fetch_one(
                "SELECT COUNT(*) total FROM orders WHERE status IN ('Chờ xử lý','Đang xử lý')"
            )["total"],
            "Cảnh báo tồn": self.db.fetch_one(
                "SELECT COUNT(*) total FROM alerts WHERE related_table='products' AND status='Đang mở'"
            )["total"],
        }
        for key, value in values.items():
            self.kpi_labels[key].configure(text=f"{int(value):,}".replace(",", "."))
        low_count = int(values["Cảnh báo tồn"])
        if low_count:
            self.mascot_tip.configure(text=f"Có {low_count} mặt hàng cần bổ sung.\nMình xem trước nhé!")
        else:
            self.mascot_tip.configure(text="Hôm nay tồn kho đang ổn đó!")

        self.order_tree.delete(*self.order_tree.get_children())
        recent_orders = self.db.fetch_all(
            """
            SELECT o.id, o.code, c.name AS customer_name, oi.quantity, o.status
            FROM orders o
            JOIN customers c ON c.id=o.customer_id
            JOIN order_items oi ON oi.order_id=o.id
            ORDER BY o.order_date DESC, o.id DESC
            LIMIT 5
            """
        )
        for index, row in enumerate(recent_orders):
            self.order_tree.insert(
                "",
                "end",
                iid=row["id"],
                values=(row["code"], row["customer_name"], row["quantity"], row["status"]),
                tags=("even" if index % 2 == 0 else "odd",),
            )
        self.order_tree.tag_configure("odd", background="#fffaf2")
        self.order_tree.tag_configure("even", background="#ffffff")

        for child in self.low_stock_frame.winfo_children():
            child.destroy()
        low_stock = self.db.fetch_all(
            """
            SELECT p.sku, p.name, COALESCE(SUM(i.quantity),0) AS quantity, p.min_stock
            FROM products p
            LEFT JOIN inventory i ON i.product_id=p.id
            GROUP BY p.id, p.sku, p.name, p.min_stock
            HAVING quantity <= p.min_stock
            ORDER BY quantity ASC, p.sku
            LIMIT 5
            """
        )
        if not low_stock:
            ttk.Label(
                self.low_stock_frame,
                text="✓  Tồn kho đang ở mức an toàn",
                style="HeroTip.TLabel",
            ).pack(fill="x", pady=6)
            return
        for row in low_stock:
            line = ttk.Frame(self.low_stock_frame, style="WarmCard.TFrame", padding=(10, 7))
            line.pack(fill="x", pady=(0, 6))
            ttk.Label(line, text=row["sku"], style="KpiAccent.TLabel").pack(side="left")
            ttk.Label(
                line,
                text=f"{row['name']}  ·  còn {row['quantity']} / tối thiểu {row['min_stock']}",
                style="KpiAccent.TLabel",
            ).pack(side="left", padx=(9, 0))
