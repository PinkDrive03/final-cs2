from __future__ import annotations

import mysql.connector
from mysql.connector import Error

import config


class DatabaseError(Exception):
    pass


class DatabaseManager:
    def __init__(self):
        self.connection = None

    def connect(self):
        if self.connection and self.connection.is_connected():
            return
        try:
            self.connection = mysql.connector.connect(
                host=config.DB_HOST,
                user=config.DB_USER,
                password=config.DB_PASSWORD,
                port=config.DB_PORT,
                charset="utf8mb4",
                collation="utf8mb4_unicode_ci",
            )
            self._create_database_if_needed()
            self.connection.database = config.DB_NAME
            self.connection.autocommit = False
            self.initialize_schema()
        except Error as exc:
            raise DatabaseError(f"Khong the ket noi MySQL: {exc}") from exc

    def _create_database_if_needed(self):
        cursor = self.connection.cursor()
        cursor.execute(
            f"CREATE DATABASE IF NOT EXISTS `{config.DB_NAME}` "
            "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )
        cursor.close()

    def close(self):
        if self.connection and self.connection.is_connected():
            self.connection.close()

    def execute(self, query, params=None, many=False):
        self.connect()
        cursor = self.connection.cursor(dictionary=True)
        try:
            if many:
                cursor.executemany(query, params or [])
            else:
                cursor.execute(query, params or ())
            return cursor
        except Error as exc:
            cursor.close()
            raise DatabaseError(str(exc)) from exc

    def fetch_one(self, query, params=None):
        cursor = self.execute(query, params)
        row = cursor.fetchone()
        cursor.close()
        return row

    def fetch_all(self, query, params=None):
        cursor = self.execute(query, params)
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def insert(self, query, params=None):
        cursor = self.execute(query, params)
        last_id = cursor.lastrowid
        cursor.close()
        return last_id

    def commit(self):
        self.connection.commit()

    def rollback(self):
        if self.connection:
            self.connection.rollback()

    def initialize_schema(self):
        statements = [
            """
            CREATE TABLE IF NOT EXISTS customers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(20) NOT NULL UNIQUE,
                name VARCHAR(150) NOT NULL,
                phone VARCHAR(30),
                address VARCHAR(255)
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS warehouses (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(20) NOT NULL UNIQUE,
                name VARCHAR(150) NOT NULL,
                address VARCHAR(255) NOT NULL
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS warehouse_locations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                warehouse_id INT NOT NULL,
                code VARCHAR(30) NOT NULL,
                area VARCHAR(10) NOT NULL,
                rack VARCHAR(10) NOT NULL,
                bin VARCHAR(10) NOT NULL,
                UNIQUE (warehouse_id, code),
                FOREIGN KEY (warehouse_id) REFERENCES warehouses(id)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sku VARCHAR(30) NOT NULL UNIQUE,
                name VARCHAR(150) NOT NULL,
                unit VARCHAR(20) NOT NULL DEFAULT 'cai',
                min_stock INT NOT NULL DEFAULT 0,
                CHECK (min_stock >= 0)
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS inventory (
                id INT AUTO_INCREMENT PRIMARY KEY,
                product_id INT NOT NULL,
                location_id INT NOT NULL,
                quantity INT NOT NULL DEFAULT 0,
                UNIQUE (product_id, location_id),
                CHECK (quantity >= 0),
                FOREIGN KEY (product_id) REFERENCES products(id)
                    ON UPDATE CASCADE ON DELETE RESTRICT,
                FOREIGN KEY (location_id) REFERENCES warehouse_locations(id)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(30) NOT NULL UNIQUE,
                customer_id INT NOT NULL,
                order_date DATE NOT NULL,
                delivery_address VARCHAR(255) NOT NULL,
                priority VARCHAR(30) NOT NULL,
                status VARCHAR(30) NOT NULL,
                FOREIGN KEY (customer_id) REFERENCES customers(id)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS order_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                product_id INT NOT NULL,
                quantity INT NOT NULL,
                CHECK (quantity > 0),
                FOREIGN KEY (order_id) REFERENCES orders(id)
                    ON UPDATE CASCADE ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products(id)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS shipments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(30) NOT NULL UNIQUE,
                order_id INT NOT NULL UNIQUE,
                origin VARCHAR(150) NOT NULL,
                destination VARCHAR(150) NOT NULL,
                departure_date DATE,
                expected_arrival DATE NOT NULL,
                actual_arrival DATE,
                container_id INT NULL,
                vehicle_id INT NULL,
                status VARCHAR(30) NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders(id)
                    ON UPDATE CASCADE ON DELETE RESTRICT
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS containers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(30) NOT NULL UNIQUE,
                type VARCHAR(20) NOT NULL,
                shipment_id INT NULL,
                current_location VARCHAR(150) NOT NULL,
                port_from VARCHAR(150),
                port_to VARCHAR(150),
                departure_date DATE,
                eta DATE,
                status VARCHAR(40) NOT NULL,
                FOREIGN KEY (shipment_id) REFERENCES shipments(id)
                    ON UPDATE CASCADE ON DELETE SET NULL
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS vehicles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(30) NOT NULL UNIQUE,
                plate VARCHAR(30) NOT NULL UNIQUE,
                vehicle_type VARCHAR(60) NOT NULL,
                capacity DECIMAL(10,2) NOT NULL,
                driver VARCHAR(100) NOT NULL,
                status VARCHAR(40) NOT NULL,
                current_shipment_id INT NULL,
                FOREIGN KEY (current_shipment_id) REFERENCES shipments(id)
                    ON UPDATE CASCADE ON DELETE SET NULL
            ) ENGINE=InnoDB
            """,
            """
            CREATE TABLE IF NOT EXISTS alerts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(30) NOT NULL UNIQUE,
                type VARCHAR(50) NOT NULL,
                related_table VARCHAR(50) NOT NULL,
                related_id INT NOT NULL,
                issue_key VARCHAR(120) NOT NULL UNIQUE,
                content VARCHAR(255) NOT NULL,
                severity VARCHAR(30) NOT NULL,
                created_at DATETIME NOT NULL,
                status VARCHAR(30) NOT NULL
            ) ENGINE=InnoDB
            """,
        ]
        cursor = self.connection.cursor()
        try:
            for statement in statements:
                cursor.execute(statement)
            self.connection.commit()
        finally:
            cursor.close()
