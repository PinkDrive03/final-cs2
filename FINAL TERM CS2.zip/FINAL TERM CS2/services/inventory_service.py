from database.database_manager import DatabaseError
from utils.helpers import inventory_status, next_code, parse_location_code


class InventoryService:
    def __init__(self, db, alert_service):
        self.db = db
        self.alert_service = alert_service

    def products_for_choice(self):
        return self.db.fetch_all("SELECT id, sku, name FROM products ORDER BY sku")

    def warehouses_for_choice(self):
        return self.db.fetch_all("SELECT id, code, name FROM warehouses ORDER BY code")

    def locations_for_choice(self):
        return self.db.fetch_all(
            """
            SELECT wl.id, wl.code, w.code AS warehouse_code
            FROM warehouse_locations wl
            JOIN warehouses w ON w.id=wl.warehouse_id
            ORDER BY w.code, wl.code
            """
        )

    def list_inventory(self, filters=None):
        filters = filters or {}
        sql = """
            SELECT i.id, p.id AS product_id, p.sku, p.name AS product_name,
                   w.code AS warehouse_code, w.name AS warehouse_name,
                   wl.code AS location_code, wl.area, wl.rack, wl.bin,
                   i.quantity, p.min_stock
            FROM inventory i
            JOIN products p ON p.id=i.product_id
            JOIN warehouse_locations wl ON wl.id=i.location_id
            JOIN warehouses w ON w.id=wl.warehouse_id
            WHERE 1=1
        """
        params = []
        if filters.get("keyword"):
            sql += " AND (p.sku LIKE %s OR p.name LIKE %s)"
            kw = f"%{filters['keyword']}%"
            params += [kw, kw]
        if filters.get("warehouse"):
            sql += " AND w.code=%s"
            params.append(filters["warehouse"])
        sql += " ORDER BY p.sku, w.code, wl.code"
        rows = self.db.fetch_all(sql, tuple(params))
        status_filter = filters.get("status")
        result = []
        for row in rows:
            row["stock_status"] = inventory_status(row["quantity"], row["min_stock"])
            if not status_filter or row["stock_status"] == status_filter:
                result.append(row)
        return result

    def add_product(self, sku, name, unit, min_stock, location_id, quantity):
        existing = self.db.fetch_one("SELECT id FROM products WHERE sku=%s", (sku,))
        if existing:
            raise ValueError("SKU đã tồn tại.")
        product_id = self.db.insert(
            "INSERT INTO products (sku,name,unit,min_stock) VALUES (%s,%s,%s,%s)",
            (sku, name, unit, min_stock),
        )
        self.db.insert(
            "INSERT INTO inventory (product_id, location_id, quantity) VALUES (%s,%s,%s)",
            (product_id, location_id, quantity),
        )
        self.evaluate_stock(product_id)
        self.db.commit()

    def update_inventory(self, inventory_id, name, min_stock, quantity):
        row = self.db.fetch_one("SELECT product_id FROM inventory WHERE id=%s", (inventory_id,))
        if not row:
            raise ValueError("Không tìm thấy dòng tồn kho.")
        self.db.execute("UPDATE products SET name=%s, min_stock=%s WHERE id=%s", (name, min_stock, row["product_id"])).close()
        self.db.execute("UPDATE inventory SET quantity=%s WHERE id=%s", (quantity, inventory_id)).close()
        self.evaluate_stock(row["product_id"])
        self.db.commit()

    def adjust_stock(self, inventory_id, delta):
        row = self.db.fetch_one("SELECT product_id, quantity FROM inventory WHERE id=%s", (inventory_id,))
        if not row:
            raise ValueError("Không tìm thấy tồn kho.")
        new_quantity = row["quantity"] + delta
        if new_quantity < 0:
            raise ValueError("Tồn kho không đủ, không được xuất âm.")
        self.db.execute("UPDATE inventory SET quantity=%s WHERE id=%s", (new_quantity, inventory_id)).close()
        self.evaluate_stock(row["product_id"])
        self.db.commit()

    def total_stock(self, product_id):
        row = self.db.fetch_one("SELECT COALESCE(SUM(quantity),0) AS total FROM inventory WHERE product_id=%s", (product_id,))
        return int(row["total"] or 0)

    def deduct_product_stock(self, product_id, quantity):
        remaining = quantity
        rows = self.db.fetch_all(
            "SELECT id, quantity FROM inventory WHERE product_id=%s AND quantity>0 ORDER BY quantity DESC",
            (product_id,),
        )
        for row in rows:
            if remaining <= 0:
                break
            take = min(remaining, row["quantity"])
            self.db.execute("UPDATE inventory SET quantity=quantity-%s WHERE id=%s", (take, row["id"])).close()
            remaining -= take
        if remaining > 0:
            raise ValueError("Tồn kho không đủ để xử lý đơn hàng.")
        self.evaluate_stock(product_id)

    def evaluate_stock(self, product_id):
        product = self.db.fetch_one("SELECT sku, name, min_stock FROM products WHERE id=%s", (product_id,))
        if not product:
            return
        total = self.total_stock(product_id)
        low_key = f"stock_low:{product_id}"
        zero_key = f"stock_zero:{product_id}"
        if total == 0:
            self.alert_service.create_unique(
                "Hết hàng",
                "products",
                product_id,
                zero_key,
                f"Sản phẩm {product['sku']} - {product['name']} đã hết hàng.",
                "Nghiêm trọng",
            )
        elif total <= product["min_stock"]:
            self.alert_service.create_unique(
                "Sắp hết hàng",
                "products",
                product_id,
                low_key,
                f"Sản phẩm {product['sku']} - {product['name']} đã xuống dưới mức tồn tối thiểu.",
                "Cảnh báo",
            )
            self.alert_service.resolve_issue(zero_key)
        else:
            self.alert_service.resolve_issue(low_key)
            self.alert_service.resolve_issue(zero_key)

    def add_warehouse(self, code, name, address):
        if self.db.fetch_one("SELECT id FROM warehouses WHERE code=%s", (code,)):
            raise ValueError("Mã kho đã tồn tại.")
        self.db.insert("INSERT INTO warehouses (code,name,address) VALUES (%s,%s,%s)", (code, name, address))
        self.db.commit()

    def add_location(self, warehouse_id, location_code):
        area, rack, bin_code = parse_location_code(location_code)
        if not area:
            raise ValueError("Vị trí phải theo dạng A-01-02.")
        try:
            self.db.insert(
                "INSERT INTO warehouse_locations (warehouse_id,code,area,rack,bin) VALUES (%s,%s,%s,%s,%s)",
                (warehouse_id, location_code, area, rack, bin_code),
            )
            self.db.commit()
        except DatabaseError as exc:
            raise ValueError("Vị trí đã tồn tại trong kho hoặc dữ liệu không hợp lệ.") from exc

    def search_location(self, keyword):
        return self.list_inventory({"keyword": keyword})

